/* credentials.js — Credentials page (requires common.js) */
'use strict';

var _data     = null;
var _envStats = null;

window._onHostReady = async function() {
  el('credPanel').innerHTML = '';
  await Promise.all([loadFromCache(), _loadEnvSummary()]);
};

window._onEnvChange = function() {
  _envStats = null;
  var bar = el('envStatsBar');
  if (bar) bar.style.display = 'none';
};

async function loadFromCache() {
  try {
    var res  = await fetch('/api/summary?host=' + enc(_activeHost));
    var data = await res.json();
    if (data.success && data.credentials && data.credentials.length) {
      _data = data;
      renderAll(data);
      el('emptyState').style.display = 'none';
      setStatus('fresh', data.synced_at);
    } else {
      el('emptyState').innerHTML     = 'No cached data yet \u2014 press <strong>\u21ba Refresh from AAP</strong> to fetch.';
      el('emptyState').style.display = 'block';
      setStatus('empty', null);
      _enableBtn();
    }
  } catch(e) {
    el('emptyState').innerHTML     = '&#x2717; Failed to load: ' + esc(e.message);
    el('emptyState').style.display = 'block';
    setStatus('empty', null);
    _enableBtn();
  }
}

function renderAll(data) {
  var s     = data.stats || {};
  var creds = data.credentials || [];
  var statsRow = el('statsRow');
  if (statsRow) {
    statsRow.style.display = 'grid';
    statsRow.innerHTML =
      statCard(s.total_credentials || 0, 'Total Credentials') +
      statCard(s.org_credentials   || 0, 'Org Credentials')   +
      statCard(s.global_credentials|| 0, 'Global Credentials');
  }
  el('credPanel').innerHTML = renderCredentials(creds);
}

function statCard(val, label) {
  return '<div class="stat"><div class="stat-val">' + val + '</div><div class="stat-label">' + label + '</div></div>';
}

function renderCredentials(creds) {
  if (!creds.length) return '<div class="state">No credentials cached yet.</div>';
  var org_creds    = creds.filter(function(c){ return c.has_org; });
  var global_creds = creds.filter(function(c){ return !c.has_org; });

  function credRows(list) {
    return list.map(function(c) {
      var username = c.username ? '<span class="id-chip">' + esc(c.username) + '</span>' : '<span class="na">\u2014</span>';
      var usage    = c.usage_count > 0
        ? '<span class="ee-tag"><span class="dot"></span>' + c.usage_count + ' use' + (c.usage_count !== 1 ? 's' : '') + '</span>'
        : '<span class="na">\u2014</span>';
      var org = c.org_name ? '<span class="org-badge">' + esc(c.org_name) + '</span>' : '<span class="na">global</span>';
      return '<tr>'
        + '<td><span class="id-chip">#' + c.id + '</span></td>'
        + '<td><strong>' + esc(c.name) + '</strong>'
        + (c.description ? '<br><span style="font-size:.68rem;color:var(--muted)">' + esc(c.description) + '</span>' : '')
        + '</td>'
        + '<td>' + org + '</td>'
        + '<td><span class="pull-badge">' + esc(c.ctype_name || '\u2014') + '</span></td>'
        + '<td>' + username + '</td>'
        + '<td>' + usage + '</td>'
        + '</tr>';
    }).join('');
  }

  var html = '';
  if (org_creds.length) {
    html += '<div class="section-meta" style="margin-top:0">'
      + '<h2>Organization Credentials</h2>'
      + '<span class="count-badge">' + org_creds.length + ' total</span>'
      + '<span class="endpoint-badge">GET /api/credentials</span></div>'
      + '<div class="search-wrap"><input class="search" placeholder="Filter by name, org or type..." oninput="filterTable(this,\'tbl-creds-org\')"/></div>'
      + '<div class="table-wrap"><table id="tbl-creds-org">'
      + '<thead><tr><th>ID</th><th>Name</th><th>Organization</th><th>Type</th><th>Username</th><th>Usage</th></tr></thead>'
      + '<tbody>' + credRows(org_creds) + '</tbody></table></div>';
  }
  if (global_creds.length) {
    html += '<div class="section-meta" style="margin-top:24px">'
      + '<h2>Global Credentials</h2>'
      + '<span class="count-badge">' + global_creds.length + ' total</span></div>'
      + '<div class="search-wrap"><input class="search" placeholder="Filter by name or type..." oninput="filterTable(this,\'tbl-creds-global\')"/></div>'
      + '<div class="table-wrap"><table id="tbl-creds-global">'
      + '<thead><tr><th>ID</th><th>Name</th><th>Organization</th><th>Type</th><th>Username</th><th>Usage</th></tr></thead>'
      + '<tbody>' + credRows(global_creds) + '</tbody></table></div>';
  }
  return html;
}

async function _loadEnvSummary() {
  await loadEnvSummary(function(data) {
    _envStats = data;
    var bar = el('envStatsBar');
    if (!bar) return;
    var t = data.totals || {}, hosts = data.hosts || [];
    var online = hosts.filter(function(h){ return h.has_data; }).length;
    bar.innerHTML =
      '<span class="env-stats-label">' + esc(data.env_label) + ' totals</span>' +
      envStatChip(t.total_credentials  || 0, 'Credentials') +
      envStatChip(t.org_credentials    || 0, 'Org Credentials',    t.total_credentials) +
      envStatChip(t.global_credentials || 0, 'Global Credentials', t.total_credentials) +
      '<span class="env-stats-hosts">' + online + ' of ' + hosts.length + ' hosts cached</span>';
    bar.style.display = 'flex';
  });
}

function triggerRefresh() { startRefresh('credentials'); }

window.addEventListener('DOMContentLoaded', commonBoot);
