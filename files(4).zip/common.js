/* common.js — shared nav, status bar, and boot helpers used by every page */
'use strict';

// ── Globals set by each page before calling commonBoot() ──────
// window._PAGE_SCOPE  = 'ee' | 'credentials' | null  (used for refresh)
// window._onHostReady = async function()  (called after host selected)
// window._onEnvChange = function()        (optional — called on env switch)

var _envs         = [];
var _activeEnv    = null;
var _activeHost   = null;
var _allowRefresh = true;
var _pollTimer    = null;

var ENV_COLORS = ['var(--accent)','var(--accent2)','var(--accent3)','var(--accent4)'];
var TTL_MINUTES = 30;

// ── Tiny helpers ──────────────────────────────────────────────
function el(id)  { return document.getElementById(id); }
function enc(s)  { return encodeURIComponent(s); }
function esc(s)  {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Boot ──────────────────────────────────────────────────────
async function commonBoot() {
  if (window.location.protocol === 'file:') {
    el('emptyState').innerHTML = '&#x2717; Serve via Flask: <strong>python app.py</strong>';
    return;
  }
  try {
    let res;
    try { res = await fetch('/api/hosts'); }
    catch(e) { throw new Error('Cannot reach Flask — is app.py running? ' + e.message); }

    if (!res.ok) {
      const body = await res.text().catch(function(){ return ''; });
      throw new Error('/api/hosts returned ' + res.status + ': ' + body.slice(0, 120));
    }

    let data;
    try { data = await res.json(); }
    catch(e) { throw new Error('/api/hosts returned non-JSON — check app.py terminal'); }

    if (!data.success) throw new Error(data.error || 'Unknown error from /api/hosts');
    if (!Array.isArray(data.environments) || !data.environments.length)
      throw new Error('No environments returned — check ENVIRONMENTS in config.py');

    _envs       = data.environments;
    _activeEnv  = data.default_env  || _envs[0].key;
    _activeHost = data.default_host || _envs[0].hosts[0].key;

    var allKeys = _envs.reduce(function(acc, e){ return acc.concat(e.hosts.map(function(h){ return h.key; })); }, []);
    if (!allKeys.includes(_activeHost)) _activeHost = allKeys[0];

    var activeEnvObj = _envs.find(function(e){ return e.key === _activeEnv; });
    _allowRefresh = activeEnvObj ? activeEnvObj.allow_refresh !== false : true;

    buildEnvTabs();
    renderHostPills(_activeEnv);
    _updateHostUrl(_activeHost);

    var envBar = el('envBar');
    if (envBar) envBar.style.display = 'block';
    _showStatusBar();
    _enableBtn();

    if (window._onHostReady) await window._onHostReady();

  } catch(e) {
    console.error('commonBoot() failed:', e);
    el('emptyState').innerHTML =
      '&#x2717; ' + esc(e.message) +
      '<br><small style="color:var(--muted)">Check browser console and app terminal.</small>';
    _enableBtn();
  }
}

// ── Env / host nav ────────────────────────────────────────────
function buildEnvTabs() {
  var container = el('envTabs');
  if (!container) return;
  container.innerHTML = '';
  _envs.forEach(function(env, i) {
    var color = ENV_COLORS[i % ENV_COLORS.length];
    var b = document.createElement('button');
    b.className = 'env-tab' + (env.key === _activeEnv ? ' active' : '');
    b.id        = 'env-tab-' + env.key;
    b.innerHTML = '<span class="env-dot" style="background:' + color + '"></span>' + esc(env.label);
    b.onclick   = function(){ selectEnv(env.key); };
    container.appendChild(b);
  });
}

function renderHostPills(envKey) {
  var container = el('hostPills');
  if (!container) return;
  var env = _envs.find(function(e){ return e.key === envKey; });
  if (!env) return;
  container.innerHTML = '';
  env.hosts.forEach(function(h) {
    var b = document.createElement('button');
    b.className   = 'pill' + (h.key === _activeHost ? ' active' : '');
    b.id          = 'pill-' + h.key;
    b.textContent = h.label;
    b.onclick     = function(){ selectHost(h.key); };
    container.appendChild(b);
  });
}

function selectEnv(envKey) {
  if (_activeEnv === envKey) return;
  _activeEnv  = envKey;
  var env     = _envs.find(function(e){ return e.key === envKey; });
  _activeHost = env ? env.hosts[0].key : _activeHost;
  _allowRefresh = env ? env.allow_refresh !== false : true;

  document.querySelectorAll('.env-tab').forEach(function(t){
    t.classList.toggle('active', t.id === 'env-tab-' + envKey);
  });
  renderHostPills(envKey);
  _updateHostUrl(_activeHost);

  if (window._onEnvChange) window._onEnvChange();
  if (window._onHostReady) window._onHostReady();
}

function selectHost(hostKey) {
  if (_activeHost === hostKey) return;
  _activeHost = hostKey;
  document.querySelectorAll('.pill').forEach(function(p){
    p.classList.toggle('active', p.id === 'pill-' + hostKey);
  });
  _updateHostUrl(hostKey);
  if (window._onHostReady) window._onHostReady();
}

function _updateHostUrl(hostKey) {
  var urlEl = el('hostUrl');
  if (!urlEl) return;
  for (var i = 0; i < _envs.length; i++) {
    var host = _envs[i].hosts.find(function(h){ return h.key === hostKey; });
    if (host) { urlEl.textContent = host.url || ''; return; }
  }
}

// ── Status bar ────────────────────────────────────────────────
function _showStatusBar() {
  var bar = el('statusBar');
  if (bar) bar.style.display = 'flex';
}

function setStatus(state, syncedAt, errMsg) {
  _showStatusBar();
  var dot  = el('statusDot');
  var text = el('statusText');
  var ttl  = el('ttlText');
  if (!dot || !text) return;

  dot.className = 'status-dot ' + state;

  if (state === 'error') {
    text.innerHTML = '<span style="color:var(--danger)">&#x2717; ' + esc(errMsg || 'Unknown error') + '</span>';

  } else if (state === 'refreshing') {
    text.innerHTML = '<span class="spinner warn"></span>Fetching from AAP \u2014 UI remains usable';

  } else if (syncedAt) {
    var d          = new Date(syncedAt);
    var ageSeconds = Math.round((Date.now() - d.getTime()) / 1000);
    var ttlSeconds = TTL_MINUTES * 60;
    var remaining  = ttlSeconds - ageSeconds;
    var isStale    = ageSeconds > ttlSeconds;

    var agoStr = ageSeconds < 60    ? ageSeconds + 's ago'
               : ageSeconds < 3600  ? Math.round(ageSeconds / 60) + 'm ago'
               : Math.round(ageSeconds / 3600) + 'h ago';

    var dateStr      = d.toLocaleDateString() + ' ' + d.toLocaleTimeString();
    var staleWarning = isStale ? ' <span style="color:var(--warn);margin-left:6px">&#9888; stale</span>' : '';

    dot.className  = 'status-dot ' + (isStale ? 'error' : 'fresh');
    text.innerHTML = '<strong>' + (isStale ? 'Stale cache' : 'Cached') + '</strong>'
      + ' \u00b7 last synced ' + agoStr
      + ' <span style="opacity:.6">(' + dateStr + ')</span>'
      + staleWarning;

    if (ttl) {
      ttl.textContent = isStale ? 'TTL expired' : 'TTL: ' + Math.ceil(remaining / 60) + 'min left';
      ttl.style.color = isStale ? 'var(--warn)' : '';
    }
    return;

  } else {
    text.innerHTML = 'No cached data \u2014 press <strong>\u21ba Refresh from AAP</strong>';
  }

  if (ttl) { ttl.textContent = ''; ttl.style.color = ''; }
}

// ── Refresh button helpers ────────────────────────────────────
function _enableBtn() {
  var b = el('forceBtn');
  if (!b) return;
  b.disabled    = !_allowRefresh;
  b.title       = _allowRefresh ? '' : 'Refresh is disabled for this environment';
  b.textContent = '\u21ba Refresh from AAP';
}
function _disableBtn() {
  var b = el('forceBtn');
  if (!b) return;
  b.disabled    = true;
  b.textContent = '\u21ba Refreshing...';
}

// ── Generic scoped refresh + poll ────────────────────────────
// Pages that use the refresh/poll pattern call startRefresh(scope)
async function startRefresh(scope) {
  if (!_allowRefresh) return;
  clearInterval(_pollTimer);
  _disableBtn();
  setStatus('refreshing', null);

  try {
    var res  = await fetch('/api/refresh?host=' + enc(_activeHost) + '&scope=' + scope + '&force=true', { method: 'POST' });
    if (!res.ok) throw new Error('Server ' + res.status);
    var data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to start refresh');
    _pollTimer = setInterval(function(){ pollRefresh(scope); }, 3000);
  } catch(e) {
    console.error('startRefresh failed:', e);
    setStatus('error', null, e.message);
    _enableBtn();
  }
}

async function pollRefresh(scope) {
  try {
    var res    = await fetch('/api/refresh/status?host=' + enc(_activeHost) + '&scope=' + scope);
    var status = await res.json();

    if (status.status === 'done' || status.status === 'idle') {
      clearInterval(_pollTimer);
      if (window._onHostReady) await window._onHostReady();
      _enableBtn();
    } else if (status.status === 'error') {
      clearInterval(_pollTimer);
      setStatus('error', null, status.error || 'Refresh failed');
      _enableBtn();
    }
  } catch(e) {
    clearInterval(_pollTimer);
    setStatus('error', null, e.message);
    _enableBtn();
  }
}

// ── Env summary bar (used by EE + credentials pages) ─────────
async function loadEnvSummary(renderFn) {
  try {
    var res  = await fetch('/api/summary/env?env=' + enc(_activeEnv));
    var data = await res.json();
    if (data.success && renderFn) renderFn(data);
  } catch(e) {
    console.warn('loadEnvSummary failed:', e);
  }
}

function envStatChip(val, label, total) {
  var sub = total != null ? '<span class="env-chip-sub"> of ' + total + '</span>' : '';
  return '<span class="env-stat-chip"><strong>' + val + '</strong> ' + label + sub + '</span>';
}

// ── Table filter helper ───────────────────────────────────────
function filterTable(inputOrVal, tableId) {
  var q = (typeof inputOrVal === 'string' ? inputOrVal : inputOrVal.value).toLowerCase();
  document.querySelectorAll('#' + tableId + ' tbody tr').forEach(function(row){
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
