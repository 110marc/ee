/* ldap.js — LDAP settings + org mapping viewer (requires common.js) */
'use strict';

var _data = null;

window._onHostReady = async function() {
  showEmpty('<span class="spinner"></span> Loading LDAP settings...');
  el('ldapContent').style.display = 'none';
  try {
    var res  = await fetch('/api/ldap?host=' + enc(_activeHost));
    var data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to load LDAP data');
    _data = data;
    renderLdap(data);
  } catch(e) {
    showEmpty('<div class="error-box">&#x2717; ' + esc(e.message) + '</div>No cached data — use Refresh from AAP to fetch.');
  }
};

async function triggerRefresh() {
  var btn = el('refreshBtn');
  btn.disabled = true; btn.textContent = '\u21ba Refreshing...';
  try {
    var res  = await fetch('/api/ldap?host=' + enc(_activeHost) + '&force=true');
    var data = await res.json();
    if (!data.success) throw new Error(data.error);
    _data = data; renderLdap(data);
  } catch(e) {
    showEmpty('<div class="error-box">&#x2717; ' + esc(e.message) + '</div>');
  } finally {
    btn.disabled = false; btn.textContent = '\u21ba Refresh from AAP';
  }
}

function showEmpty(msg) {
  el('emptyState').innerHTML = msg;
  el('emptyState').style.display = 'block';
  el('ldapContent').style.display = 'none';
}

function renderLdap(data) {
  if (!data.configured) { showEmpty('No LDAP configuration found on this host.'); return; }
  el('emptyState').style.display  = 'none';
  el('ldapContent').style.display = 'block';

  var mappedCount   = (data.mapped_orgs   || []).length;
  var unmappedCount = (data.unmapped_orgs || []).length;
  var teamCount     = Object.keys(data.team_map || {}).length;

  var html =
    '<div class="stats" style="margin-bottom:24px">' +
    statCard(mappedCount,   'Orgs Mapped',   mappedCount   ? 'var(--success)' : 'var(--muted)') +
    statCard(unmappedCount, 'Orgs Unmapped', unmappedCount ? 'var(--danger)'  : 'var(--success)') +
    statCard(teamCount,     'Team Maps',     'var(--accent)') +
    '</div>';

  var categories = data.categories || {};
  var catNames   = Object.keys(categories);
  if (catNames.length) {
    html += '<div class="ldap-block">';
    html += '<div class="section-meta" style="margin-bottom:16px"><h2>Settings</h2>'
          + '<span class="endpoint-badge">GET /api/v2/settings/ldap/</span></div>';
    catNames.forEach(function(cat) {
      html += '<div class="cat-label">' + esc(cat) + '</div>';
      html += '<div class="info-grid" style="margin-bottom:14px">';
      categories[cat].forEach(function(row) {
        var val = row.hidden ? '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022' : formatValue(row.value);
        html += '<div class="info-row">'
          + '<span class="info-label">' + esc(row.key) + '</span>'
          + '<span class="info-value">' + val + '</span>'
          + '</div>';
      });
      html += '</div>';
    });
    html += '</div>';
  }

  html += renderOrgMap(data);
  el('ldapContent').innerHTML = html;

  var filterInp = el('orgFilter');
  if (filterInp) filterInp.oninput = function(){ filterTable(this, 'orgTable'); };
}

function renderOrgMap(data) {
  var orgMap       = data.org_map       || {};
  var mappedOrgs   = data.mapped_orgs   || [];
  var unmappedOrgs = data.unmapped_orgs || [];
  var total        = mappedOrgs.length + unmappedOrgs.length;
  var rows = '';

  mappedOrgs.forEach(function(orgName) {
    var m = orgMap[orgName] || {};
    rows += '<tr>'
      + '<td><span class="org-name">' + esc(orgName) + '</span></td>'
      + '<td><span class="mapped-badge">&#x2713; Mapped</span></td>'
      + '<td>' + groupTags(extractGroups(m.admins)) + '</td>'
      + '<td>' + groupTags(extractGroups(m.users))  + '</td>'
      + '<td>' + (m.remove_admins ? '<span class="warn-badge">Yes</span>' : '<span class="na">No</span>') + '</td>'
      + '<td>' + (m.remove_users  ? '<span class="warn-badge">Yes</span>' : '<span class="na">No</span>') + '</td>'
      + '</tr>';
  });

  unmappedOrgs.forEach(function(orgName) {
    rows += '<tr class="unmapped-row">'
      + '<td><span class="org-name muted">' + esc(orgName) + '</span></td>'
      + '<td><span class="unmapped-badge">&#x2717; No mapping</span></td>'
      + '<td colspan="4"><span class="na">\u2014</span></td>'
      + '</tr>';
  });

  if (!rows) rows = '<tr><td colspan="6" class="state" style="padding:32px">No organizations in cache \u2014 refresh EE first.</td></tr>';

  return '<div class="ldap-block">'
    + '<div class="section-meta"><h2>Organization Map</h2>'
    + '<span class="count-badge">' + mappedOrgs.length + ' of ' + total + ' orgs mapped</span></div>'
    + '<div class="search-wrap"><input class="search" id="orgFilter" placeholder="Filter organizations..."></div>'
    + '<div class="table-wrap"><table id="orgTable">'
    + '<thead><tr><th>Organization</th><th>Status</th><th>Admin Groups</th><th>User Groups</th><th>Remove Admins</th><th>Remove Members</th></tr></thead>'
    + '<tbody>' + rows + '</tbody></table></div></div>';
}

function formatValue(val) {
  if (val === null || val === undefined || val === '') return '<span class="na">not set</span>';
  if (typeof val === 'boolean') return val ? '<span class="mapped-badge">&#x2713; Yes</span>' : '<span class="na">No</span>';
  if (Array.isArray(val)) {
    if (!val.length) return '<span class="na">empty</span>';
    return val.map(function(item){
      return '<span class="group-tag">' + esc(Array.isArray(item) ? item.join('  ') : String(item)) + '</span>';
    }).join(' ');
  }
  if (typeof val === 'object') return '<span class="json-val">' + esc(JSON.stringify(val)) + '</span>';
  return '<span class="mono-val">' + esc(String(val)) + '</span>';
}

function extractGroups(val) {
  if (!val) return [];
  if (typeof val === 'string') return [val];
  if (Array.isArray(val)) return val.filter(function(v){ return typeof v === 'string'; });
  if (typeof val === 'object') {
    var g = val.ldap_groups || val.has_ldap_group || val.group_dn || '';
    if (typeof g === 'string' && g) return [g];
    if (Array.isArray(g)) return g;
  }
  return [];
}

function groupTags(groups) {
  if (!groups || !groups.length) return '<span class="na">\u2014</span>';
  return groups.map(function(g){
    var match = g.match(/CN=([^,]+)/i);
    var short = match ? match[1] : g;
    return '<span class="group-tag" title="' + esc(g) + '">' + esc(short) + '</span>';
  }).join(' ');
}

function statCard(val, label, color) {
  return '<div class="stat"><div class="stat-val" style="color:' + color + '">' + val + '</div><div class="stat-label">' + label + '</div></div>';
}

function exportCSV() {
  if (!_data) return;
  var rows = [['Organization','Status','Admin Groups','User Groups','Remove Admins','Remove Members']];
  var orgMap = _data.org_map || {};
  (_data.mapped_orgs || []).forEach(function(n){
    var m = orgMap[n] || {};
    rows.push([n,'Mapped',
      extractGroups(m.admins).map(function(g){ var x=g.match(/CN=([^,]+)/i); return x?x[1]:g; }).join(' | '),
      extractGroups(m.users).map(function(g){  var x=g.match(/CN=([^,]+)/i); return x?x[1]:g; }).join(' | '),
      m.remove_admins?'Yes':'No', m.remove_users?'Yes':'No']);
  });
  (_data.unmapped_orgs || []).forEach(function(n){ rows.push([n,'No mapping','','','','']); });
  var csv  = rows.map(function(r){ return r.map(function(c){ return '"'+String(c||'').replace(/"/g,'""')+'"'; }).join(','); }).join('\r\n');
  var blob = new Blob([csv],{type:'text/csv'});
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href=url; a.download='ldap-org-map.csv'; a.click();
  URL.revokeObjectURL(url);
}

window.addEventListener('DOMContentLoaded', commonBoot);
