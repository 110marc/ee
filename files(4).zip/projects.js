/* projects.js — Projects inventory (requires common.js) */
'use strict';

var _data = null;

window._onHostReady = async function() {
  showEmpty('<span class="spinner"></span> Loading projects...');
  el('projectsContent').style.display = 'none';
  try {
    var res  = await fetch('/api/projects/full?host=' + enc(_activeHost));
    var data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to load projects');
    _data = data;
    render(data);
  } catch(e) {
    showEmpty('<div class="error-box">&#x2717; ' + esc(e.message) + '</div>No cached data \u2014 use Refresh from AAP to fetch.');
  }
};

async function triggerRefresh() {
  var btn = el('refreshBtn');
  btn.disabled = true; btn.textContent = '\u21ba Refreshing...';
  try {
    var res  = await fetch('/api/projects/full?host=' + enc(_activeHost) + '&force=true');
    var data = await res.json();
    if (!data.success) throw new Error(data.error);
    _data = data; render(data);
  } catch(e) {
    showEmpty('<div class="error-box">&#x2717; ' + esc(e.message) + '</div>');
  } finally {
    btn.disabled = false; btn.textContent = '\u21ba Refresh from AAP';
  }
}

function showEmpty(msg) {
  el('emptyState').innerHTML = msg;
  el('emptyState').style.display = 'block';
  el('projectsContent').style.display = 'none';
}

function render(data) {
  el('emptyState').style.display      = 'none';
  el('projectsContent').style.display = 'block';

  var projects    = data.results || [];
  var withScm     = projects.filter(function(p){ return p.scm_url; }).length;
  var withEE      = projects.filter(function(p){ return p.ee_name; }).length;
  var noEE        = projects.length - withEE;

  var html =
    '<div class="stats" style="margin-bottom:24px">' +
    statCard(projects.length, 'Total Projects', 'var(--accent)') +
    statCard(withScm,         'With SCM URL',   'var(--blue-mid)') +
    statCard(withEE,          'With EE',        'var(--success)') +
    statCard(noEE,            'No EE',          noEE ? 'var(--warn)' : 'var(--success)') +
    '</div>';

  var rows = projects.map(function(p) {
    var scmHtml = p.scm_url
      ? '<span class="mono-val scm-url" title="' + esc(p.scm_url) + '">' + esc(p.scm_url.replace(/^https?:\/\//, '')) + '</span>'
        + (p.scm_branch ? ' <span class="pull-badge">' + esc(p.scm_branch) + '</span>' : '')
      : '<span class="na">\u2014</span>';

    var eeHtml = p.ee_name
      ? '<span class="ee-tag"><span class="dot"></span>' + esc(p.ee_name) + '</span>'
      : '<span class="na">\u2014</span>';

    var statusHtml = p.status
      ? '<span class="status-chip status-' + esc(p.status) + '">' + esc(p.status) + '</span>'
      : '<span class="na">\u2014</span>';

    return '<tr>'
      + '<td><span class="id-chip">' + p.id + '</span></td>'
      + '<td><span class="proj-name">' + esc(p.name) + '</span></td>'
      + '<td>' + (p.org_name ? '<span class="org-badge">' + esc(p.org_name) + '</span>' : '<span class="na">\u2014</span>') + '</td>'
      + '<td>' + scmHtml + '</td>'
      + '<td>' + eeHtml  + '</td>'
      + '<td>' + statusHtml + '</td>'
      + '<td>' + (p.created_by ? '<span class="user-badge">&#x1F464; ' + esc(p.created_by) + '</span>' : '<span class="na">\u2014</span>') + '</td>'
      + '</tr>';
  }).join('') || '<tr><td colspan="7" class="state">No projects found.</td></tr>';

  html += '<div class="section-meta">'
    + '<h2>Projects</h2>'
    + '<span class="count-badge">' + projects.length + ' total</span>'
    + '<span class="endpoint-badge">GET /api/v2/projects/</span>'
    + '</div>'
    + '<div class="search-wrap"><input class="search" id="projFilter" placeholder="Filter by name, org, URL or user..."></div>'
    + '<div class="table-wrap"><table id="projTable">'
    + '<thead><tr><th>ID</th><th>Name</th><th>Org</th><th>SCM URL</th><th>EE</th><th>Status</th><th>Created By</th></tr></thead>'
    + '<tbody>' + rows + '</tbody></table></div>';

  el('projectsContent').innerHTML = html;
  var f = el('projFilter');
  if (f) f.oninput = function(){ filterTable(this, 'projTable'); };
}

function statCard(val, label, color) {
  return '<div class="stat"><div class="stat-val" style="color:' + color + '">' + val + '</div><div class="stat-label">' + label + '</div></div>';
}

function exportCSV() {
  if (!_data) return;
  var rows = [['ID','Name','Organization','SCM Type','SCM URL','Branch','EE','Status','Created By']];
  (_data.results || []).forEach(function(p){
    rows.push([p.id, p.name, p.org_name, p.scm_type, p.scm_url, p.scm_branch, p.ee_name, p.status, p.created_by]);
  });
  var csv  = rows.map(function(r){ return r.map(function(c){ return '"'+String(c||'').replace(/"/g,'""')+'"'; }).join(','); }).join('\r\n');
  var blob = new Blob([csv],{type:'text/csv'});
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href=url; a.download='projects.csv'; a.click();
  URL.revokeObjectURL(url);
}

window.addEventListener('DOMContentLoaded', commonBoot);
