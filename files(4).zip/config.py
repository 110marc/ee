# ── AAP Dashboard Configuration ───────────────────────────────
#
# Two-level hierarchy:  ENVIRONMENTS  →  hosts within each env
#
# Credential inheritance (highest specificity wins):
#   1. host-level  username / password  — overrides everything
#   2. env-level   username / password  — shared across all hosts in env
#   3. DEFAULT_CREDENTIALS             — global fallback for all hosts
#
# You only need to set credentials at ONE level.
# Example: set DEFAULT_CREDENTIALS and omit username/password everywhere else.

# Global fallback credentials (used if not set at env or host level)
DEFAULT_CREDENTIALS = {
    "username": "",
    "password": "",
}

ENVIRONMENTS = {
    "production": {
        "label":          "Production",
        "allow_refresh":  False,
        "hosts": {
            "prod-us": {
                "label":      "US East",
                "url":        "https://aap-prod-us.example.com",
                "username":   "admin",
                "password":   "prod-us-password",
                "verify_ssl": False,
            },
            "prod-eu": {
                "label":      "EU West",
                "url":        "https://aap-prod-eu.example.com",
                "username":   "admin",
                "password":   "prod-eu-password",
                "verify_ssl": False,
            },
        },
    },
    "staging": {
        "label":         "Staging",
        "allow_refresh": False,
        "hosts": {
            "staging-us": {
                "label":      "US Staging",
                "url":        "https://aap-staging-us.example.com",
                "username":   "admin",
                "password":   "staging-password",
                "verify_ssl": False,
            },
            "staging-eu": {
                "label":      "EU Staging",
                "url":        "https://aap-staging-eu.example.com",
                "username":   "admin",
                "password":   "staging-eu-password",
                "verify_ssl": False,
            },
        },
    },
    "dev": {
        "label":         "Dev",
        "allow_refresh": True,
        "hosts": {
            "dev-local": {
                "label":      "Local Dev",
                "url":        "https://aap-dev.example.com",
                "username":   "admin",
                "password":   "dev-password",
                "verify_ssl": False,
            },
        },
    },
}

# Default env + host shown on first load
DEFAULT_ENV  = "production"
DEFAULT_HOST = "prod-us"

# ── Exclusion filters ────────────────────────────────────────
# Glob patterns for resource names to exclude from the dashboard.
# Supports * (any chars) and ? (single char).
# Examples: "MWD*", "TEST_*", "*_deprecated"

EXCLUDE_TEMPLATES = [
    # "MWD*",
    # "TEST_*",
]

EXCLUDE_PROJECTS = [
    # "MWD*",
]

EXCLUDE_ORGS = [
    # "MWD*",
]

# ── Cache settings ────────────────────────────────────────────
CACHE_TTL_MINUTES = 30
DB_PATH           = "aap_cache.db"

# ── Global settings ───────────────────────────────────────────
PAGE_SIZE   = 200
TIMEOUT     = 30
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 5000
