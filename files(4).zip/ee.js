/* ee.js — Execution Environment dashboard (requires common.js) */
'use strict';

var _data      = null;
var _activeRes = 'ees';
var _envStats  = null;

// ── Page wiring — called by common.js ─────────────────────────
window._onHostReady = async function() {
  clearData();
  await Promise.all([loadFromCache(), _loadEnvSummary()]);
};

window._onEnvChange = function() {
  _envStats = null;
  var bar = el('envStatsBar');
  if (bar) bar.style.display = 'none';
};

// ── Load ──────────────────────────────────────────────────────
async function loadFromCache() {
  try {
    var res  = await fetch('/api/summary?host=' + enc(_activeHost));
    var data = await res.json();

    if (data.success && (data.ees.length || data.projects.length || data.templates.length)) {
      _data = data;
      renderAll(data);
      setStatus('fresh', data.synced_at);
    } else {
      el('emptyState').innerHTML   = 'No cached data yet \u2014 press <strong>\u21ba Refresh from AAP</strong> to fetch.';
      el('emptyState').style.display = 'block';
      setStatus('empty', null);
      _enableBtn();
    }
  } catch(e) {
    el('emptyState').innerHTML   = '&#x2717; Failed to load: ' + esc(e.message);
    el('emptyState').style.display = 'block';
    setStatus('empty', null);
    _enableBtn();
  }
}

function clearData() {
  _data = null;
  ['statsRow','resTabs'].forEach(function(id){ var e = el(id); if(e) e.style.display = 'none'; });
  var expBtn = el('exportBtn');
  if (expBtn) expBtn.style.display = 'none';
  var errBox = el('errorBox');
  if (errBox) errBox.style.display = 'none';
  ['ees','orgs','projects','templates'].forEach(function(t){
    var p = el('panel-' + t);
    if (p) p.innerHTML = '';
  });
  el('emptyState').innerHTML     = '';
  el('emptyState').style.display = 'block';
  setStatus('empty', null);
  _enableBtn();
}

// ── Render ────────────────────────────────────────────────────
function renderAll(data) {
  var s  = data.stats;
  var sr = el('statsRow');
  sr.innerHTML =
    statCard(s.total_ees,         'Execution Envs',  null) +
    statCard(s.orgs_with_ee,      'Orgs w/ EE',      s.total_orgs) +
    statCard(s.projects_with_ee,  'Projects w/ EE',  s.total_projects) +
    statCard(s.templates_with_ee, 'Templates w/ EE', s.total_templates);
  sr.style.display = 'grid';

  el('panel-ees').innerHTML       = renderEEs(data.ees);
  el('panel-orgs').innerHTML      = renderOrgs(data.orgs, s.total_orgs);
  el('panel-projects').innerHTML  = renderProjects(data.projects, s.total_projects);
  el('panel-templates').innerHTML = renderTemplates(data.templates, s.total_templates);

  el('emptyState').style.display = 'none';
  el('resTabs').style.display    = 'flex';
  el('exportBtn').style.display  = 'inline-block';
  _enableBtn();
  switchResTab(_activeRes);
}

function switchResTab(name) {
  _activeRes = name;
  ['ees','orgs','projects','templates'].forEach(function(t) {
    el('panel-' + t).classList.toggle('active', t === name);
    el('tab-'   + t).classList.toggle('active', t === name);
  });
}

function statCard(val, label, total) {
  var sub = total != null ? '<div class="stat-sub">of ' + total + ' total</div>' : '';
  return '<div class="stat"><div class="stat-val">' + val + '</div><div class="stat-label">' + label + '</div>' + sub + '</div>';
}

// ── Table renderers ───────────────────────────────────────────
function renderEEs(ees) {
  var rows = ees.map(function(e) {
    return '<tr>'
      + '<td><span class="id-chip">#' + e.id + '</span></td>'
      + '<td><strong>' + esc(e.name) + '</strong></td>'
      + '<td><span class="image-text">' + esc(e.image) + '</span>'
      + (e.pull ? '<span class="pull-badge">' + esc(e.pull) + '</span>' : '') + '</td>'
      + '<td><span class="org-badge">' + esc(e.org) + '</span></td>'
      + '</tr>';
  }).join('');
  return section('Execution Environments', ees.length, null, 'tbl-ees', 'Filter by name or image...',
    '<table id="tbl-ees"><thead><tr><th>ID</th><th>Name</th><th>Image</th><th>Scope</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function renderOrgs(orgs, total) {
  if (!orgs || !orgs.length) return emptySection('No organizations have an EE assigned.');
  var rows = orgs.map(function(o) {
    return '<tr>'
      + '<td><span class="id-chip">#' + o.id + '</span></td>'
      + '<td><strong>' + esc(o.name) + '</strong></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(o.ee_name) + '</span></td>'
      + '<td><span class="id-chip">#' + o.ee_id + '</span></td>'
      + '</tr>';
  }).join('');
  return section('Organizations', orgs.length, total, 'tbl-orgs', 'Filter by org or EE name...',
    '<table id="tbl-orgs"><thead><tr><th>ID</th><th>Organization</th><th>Execution Environment</th><th>EE ID</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function renderProjects(projects, total) {
  if (!projects.length) return emptySection('No projects have an EE assigned.');
  var rows = projects.map(function(p) {
    return '<tr>'
      + '<td><span class="id-chip">#' + p.id + '</span></td>'
      + '<td><strong>' + esc(p.name) + '</strong></td>'
      + '<td><span class="org-badge">' + esc(p.org_name || '\u2014') + '</span></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(p.ee_name) + '</span></td>'
      + '<td><span class="id-chip">#' + p.ee_id + '</span></td>'
      + '</tr>';
  }).join('');
  return section('Projects', projects.length, total, 'tbl-projects', 'Filter by project, org or EE...',
    '<table id="tbl-projects"><thead><tr><th>ID</th><th>Project</th><th>Organization</th><th>Execution Environment</th><th>EE ID</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function renderTemplates(templates, total) {
  if (!templates.length) return emptySection('No job templates have an EE assigned.');
  var rows = templates.map(function(t) {
    return '<tr>'
      + '<td><span class="id-chip">#' + t.id + '</span></td>'
      + '<td><strong>' + esc(t.name) + '</strong></td>'
      + '<td><span class="org-badge">' + esc(t.org_name || '\u2014') + '</span></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(t.ee_name) + '</span></td>'
      + '<td><span class="id-chip">#' + t.ee_id + '</span></td>'
      + '</tr>';
  }).join('');
  return section('Job Templates', templates.length, total, 'tbl-templates', 'Filter by template, org or EE...',
    '<table id="tbl-templates"><thead><tr><th>ID</th><th>Template</th><th>Organization</th><th>Execution Environment</th><th>EE ID</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function section(title, count, total, tableId, placeholder, tableHtml) {
  var badge = total != null ? (count + ' of ' + total + ' have EE') : (count + ' total');
  return '<div class="section-meta">'
    + '<h2>' + title + '</h2>'
    + '<span class="count-badge">' + badge + '</span>'
    + '</div>'
    + '<div class="search-wrap"><input class="search" placeholder="' + placeholder
    + '" oninput="filterTable(this,\'' + tableId + '\')"/></div>'
    + '<div class="table-wrap">' + tableHtml + '</div>';
}

function emptySection(msg) {
  return '<div class="state">' + msg + '</div>';
}

// ── Env summary bar ───────────────────────────────────────────
async function _loadEnvSummary() {
  await loadEnvSummary(function(data) {
    _envStats = data;
    var bar = el('envStatsBar');
    if (!bar) return;
    var t     = data.totals || {};
    var hosts = data.hosts  || [];
    var online = hosts.filter(function(h){ return h.has_data; }).length;
    bar.innerHTML =
      '<span class="env-stats-label">' + esc(data.env_label) + ' totals</span>' +
      envStatChip(t.total_ees         || 0, 'EEs') +
      envStatChip(t.orgs_with_ee      || 0, 'Orgs w/ EE',      t.total_orgs) +
      envStatChip(t.projects_with_ee  || 0, 'Projects w/ EE',  t.total_projects) +
      envStatChip(t.templates_with_ee || 0, 'Templates w/ EE', t.total_templates) +
      '<span class="env-stats-hosts">' + online + ' of ' + hosts.length + ' hosts cached</span>';
    bar.style.display = 'flex';
  });
}

// ── Refresh ───────────────────────────────────────────────────
function triggerRefresh() { startRefresh('ee'); }

// ── CSV export ────────────────────────────────────────────────
function exportCSV() {
  if (!_data) return;
  var env  = _envs.find(function(e){ return e.hosts.some(function(h){ return h.key === _activeHost; }); });
  var host = env && env.hosts.find(function(h){ return h.key === _activeHost; });
  var lines = [
    'AAP EE Report \u2014 ' + (env && env.label) + ' / ' + (host && host.label) + '  (synced: ' + _data.synced_at + ')',
    'Section,ID,Name,EE Name,Extra',
  ];
  _data.ees.forEach(function(e)      { lines.push('Execution Environment,' + e.id + ',"' + e.name + '","' + e.image + '","' + e.org + '"'); });
  _data.projects.forEach(function(p) { lines.push('Project,' + p.id + ',"' + p.name + '","' + p.ee_name + '","EE ID: ' + p.ee_id + '"'); });
  _data.templates.forEach(function(t){ lines.push('Job Template,' + t.id + ',"' + t.name + '","' + t.ee_name + '","EE ID: ' + t.ee_id + '"'); });
  var a      = document.createElement('a');
  a.href     = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv' }));
  a.download = 'aap_ee_' + (env && env.key) + '_' + _activeHost + '.csv';
  a.click();
}

window.addEventListener('DOMContentLoaded', commonBoot);
