/* common.js — shared nav, status bar, refresh helpers for all pages */
'use strict';

// ── Globals ───────────────────────────────────────────────────
var _envs         = [];
var _activeEnv    = null;
var _activeHost   = null;
var _allowRefresh = true;
var _pollTimer    = null;
var ENV_COLORS    = ['var(--accent)','var(--accent2)','var(--accent3)','var(--accent4)'];
var TTL_MINUTES   = 30;

// ── Helpers ───────────────────────────────────────────────────
function el(id)  { return document.getElementById(id); }
function enc(s)  { return encodeURIComponent(s); }
function esc(s)  {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function fmtDate(iso) {
  if (!iso) return '\u2014';
  try {
    return new Date(iso).toLocaleDateString('en-GB', {day:'2-digit',month:'short',year:'numeric'});
  } catch(e) { return iso; }
}

function fmtAgo(iso) {
  if (!iso) return null;
  var d   = new Date(iso);
  var age = Math.round((Date.now() - d.getTime()) / 1000);
  var ago = age < 60   ? age + 's ago'
          : age < 3600 ? Math.round(age/60) + 'm ago'
          : Math.round(age/3600) + 'h ago';
  return ago + ' \u00b7 ' + d.toLocaleDateString() + ' ' + d.toLocaleTimeString();
}

// ── Synced-at bar (reused by all pages) ───────────────────────
function renderSyncedBar(isoStr) {
  var bar = el('syncedBar');
  if (!bar) return;
  if (!isoStr) {
    bar.style.display = 'none';
    return;
  }
  var d          = new Date(isoStr);
  var ageSeconds = Math.round((Date.now() - d.getTime()) / 1000);
  var ttlSeconds = TTL_MINUTES * 60;
  var isStale    = ageSeconds > ttlSeconds;
  var ago        = ageSeconds < 60   ? ageSeconds + 's ago'
                 : ageSeconds < 3600 ? Math.round(ageSeconds/60) + 'm ago'
                 : Math.round(ageSeconds/3600) + 'h ago';
  var dateStr    = d.toLocaleDateString() + ' ' + d.toLocaleTimeString();

  bar.innerHTML =
    '<span class="synced-dot ' + (isStale ? 'stale' : 'fresh') + '"></span>' +
    (isStale ? '<strong>Stale</strong>' : '<strong>Cached</strong>') +
    ' \u00b7 last synced <strong>' + ago + '</strong>' +
    ' <span class="synced-date">(' + dateStr + ')</span>' +
    (isStale ? ' <span class="synced-stale-warn">\u26a0 stale</span>' : '');
  bar.style.display = 'flex';
}

// ── Boot ──────────────────────────────────────────────────────
async function commonBoot() {
  if (window.location.protocol === 'file:') {
    el('emptyState').innerHTML = '&#x2717; Serve via Flask: <strong>python app.py</strong>';
    return;
  }
  try {
    var res;
    try { res = await fetch('/api/hosts'); }
    catch(e) { throw new Error('Cannot reach Flask \u2014 is app.py running? ' + e.message); }

    if (!res.ok) {
      var body = await res.text().catch(function(){ return ''; });
      throw new Error('/api/hosts returned ' + res.status + ': ' + body.slice(0,120));
    }

    var data;
    try { data = await res.json(); }
    catch(e) { throw new Error('/api/hosts returned non-JSON \u2014 check app.py terminal'); }

    if (!data.success) throw new Error(data.error || 'Unknown error');
    if (!Array.isArray(data.environments) || !data.environments.length)
      throw new Error('No environments in config.py');

    _envs       = data.environments;
    _activeEnv  = data.default_env  || _envs[0].key;
    _activeHost = data.default_host || _envs[0].hosts[0].key;

    var allKeys = _envs.reduce(function(a,e){ return a.concat(e.hosts.map(function(h){ return h.key; })); },[]);
    if (!allKeys.includes(_activeHost)) _activeHost = allKeys[0];

    var activeEnvObj = _envs.find(function(e){ return e.key === _activeEnv; });
    _allowRefresh = activeEnvObj ? activeEnvObj.allow_refresh !== false : true;

    buildEnvTabs();
    renderHostPills(_activeEnv);
    _updateHostUrl(_activeHost);

    var envBar = el('envBar');
    if (envBar) envBar.style.display = 'block';
    _enableBtn();

    if (window._onHostReady) await window._onHostReady();

  } catch(e) {
    console.error('commonBoot:', e);
    el('emptyState').innerHTML =
      '&#x2717; ' + esc(e.message) +
      '<br><small style="color:var(--muted)">Check browser console and Flask terminal.</small>';
    _enableBtn();
  }
}

// ── Env / host nav ────────────────────────────────────────────
function buildEnvTabs() {
  var wrap = el('envTabs');
  if (!wrap) return;
  wrap.innerHTML = '';
  _envs.forEach(function(env, i) {
    var b = document.createElement('button');
    b.className = 'env-tab' + (env.key === _activeEnv ? ' active' : '');
    b.id        = 'env-tab-' + env.key;
    b.innerHTML = '<span class="env-dot" style="background:' + ENV_COLORS[i % ENV_COLORS.length] + '"></span>' + esc(env.label);
    b.onclick   = function(){ selectEnv(env.key); };
    wrap.appendChild(b);
  });
}

function renderHostPills(envKey) {
  var wrap = el('hostPills');
  if (!wrap) return;
  var env = _envs.find(function(e){ return e.key === envKey; });
  if (!env) return;
  wrap.innerHTML = '';
  env.hosts.forEach(function(h) {
    var b = document.createElement('button');
    b.className   = 'pill' + (h.key === _activeHost ? ' active' : '');
    b.id          = 'pill-' + h.key;
    b.textContent = h.label;
    b.onclick     = function(){ selectHost(h.key); };
    wrap.appendChild(b);
  });
}

function selectEnv(envKey) {
  if (_activeEnv === envKey) return;
  _activeEnv  = envKey;
  var env     = _envs.find(function(e){ return e.key === envKey; });
  _activeHost = env ? env.hosts[0].key : _activeHost;
  _allowRefresh = env ? env.allow_refresh !== false : true;
  document.querySelectorAll('.env-tab').forEach(function(t){
    t.classList.toggle('active', t.id === 'env-tab-' + envKey);
  });
  renderHostPills(envKey);
  _updateHostUrl(_activeHost);
  if (window._onEnvChange) window._onEnvChange();
  if (window._onHostReady) window._onHostReady();
}

function selectHost(hostKey) {
  if (_activeHost === hostKey) return;
  _activeHost = hostKey;
  document.querySelectorAll('.pill').forEach(function(p){
    p.classList.toggle('active', p.id === 'pill-' + hostKey);
  });
  _updateHostUrl(hostKey);
  if (window._onHostReady) window._onHostReady();
}

function _updateHostUrl(hostKey) {
  var urlEl = el('hostUrl');
  if (!urlEl) return;
  for (var i = 0; i < _envs.length; i++) {
    var host = _envs[i].hosts.find(function(h){ return h.key === hostKey; });
    if (host) { urlEl.textContent = host.url || ''; return; }
  }
}

// ── Refresh helpers ───────────────────────────────────────────
function _enableBtn() {
  var b = el('forceBtn');
  if (!b) return;
  b.disabled    = !_allowRefresh;
  b.title       = _allowRefresh ? '' : 'Refresh disabled for this environment';
  b.textContent = '\u21ba Refresh from AAP';
}
function _disableBtn() {
  var b = el('forceBtn');
  if (!b) return;
  b.disabled    = true;
  b.textContent = '\u21ba Refreshing\u2026';
}

async function startRefresh(scope) {
  if (!_allowRefresh) return;
  clearInterval(_pollTimer);
  _disableBtn();
  renderSyncedBar(null);
  try {
    var res  = await fetch('/api/refresh?host=' + enc(_activeHost) + '&scope=' + scope + '&force=true', {method:'POST'});
    if (!res.ok) throw new Error('Server ' + res.status);
    var data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to start refresh');
    _pollTimer = setInterval(function(){ _pollRefresh(scope); }, 3000);
  } catch(e) {
    console.error('startRefresh:', e);
    _enableBtn();
  }
}

async function _pollRefresh(scope) {
  try {
    var res    = await fetch('/api/refresh/status?host=' + enc(_activeHost) + '&scope=' + scope);
    var status = await res.json();
    if (status.status === 'done' || status.status === 'idle') {
      clearInterval(_pollTimer);
      if (window._onHostReady) await window._onHostReady();
      _enableBtn();
    } else if (status.status === 'error') {
      clearInterval(_pollTimer);
      console.error('Refresh error:', status.error);
      _enableBtn();
    }
  } catch(e) {
    clearInterval(_pollTimer);
    console.error('pollRefresh:', e);
    _enableBtn();
  }
}

// ── Env summary bar ───────────────────────────────────────────
async function loadEnvSummary(renderFn) {
  try {
    var res  = await fetch('/api/summary/env?env=' + enc(_activeEnv));
    var data = await res.json();
    if (data.success && renderFn) renderFn(data);
  } catch(e) { /* non-critical */ }
}

function envStatChip(val, label, total) {
  var sub = total != null ? '<span class="env-chip-sub"> / ' + total + '</span>' : '';
  return '<span class="env-stat-chip"><strong>' + val + '</strong> ' + label + sub + '</span>';
}

// ── Table filter ──────────────────────────────────────────────
function filterTable(inputOrVal, tableId) {
  var q = (typeof inputOrVal === 'string' ? inputOrVal : inputOrVal.value).toLowerCase();
  document.querySelectorAll('#' + tableId + ' tbody tr').forEach(function(row){
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
