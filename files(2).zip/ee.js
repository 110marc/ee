/* ee.js — Execution Environments (requires common.js) */
'use strict';

var _data      = null;
var _activeRes = 'ees';
var _envStats  = null;

window._onHostReady = async function() {
  _clearPanels();
  await Promise.all([_load(), _loadEnvSummary()]);
};
window._onEnvChange = function() {
  _envStats = null;
  var bar = el('envStatsBar');
  if (bar) bar.style.display = 'none';
};

// ── Load ──────────────────────────────────────────────────────
async function _load() {
  try {
    var res  = await fetch('/api/summary?host=' + enc(_activeHost));
    var data = await res.json();
    if (data.success && (data.ees.length || data.projects.length || data.templates.length)) {
      _data = data;
      _render(data);
      renderSyncedBar(data.synced_at);
    } else {
      el('emptyState').innerHTML   = 'No cached data \u2014 press <strong>\u21ba Refresh from AAP</strong>';
      el('emptyState').style.display = 'block';
      renderSyncedBar(null);
      _enableBtn();
    }
  } catch(e) {
    el('emptyState').innerHTML   = '&#x2717; ' + esc(e.message);
    el('emptyState').style.display = 'block';
    renderSyncedBar(null);
    _enableBtn();
  }
}

function _clearPanels() {
  _data = null;
  renderSyncedBar(null);
  ['statsRow','resTabs'].forEach(function(id){ var e=el(id); if(e) e.style.display='none'; });
  var exp = el('exportBtn'); if(exp) exp.style.display='none';
  ['ees','orgs','projects','templates'].forEach(function(t){ var p=el('panel-'+t); if(p) p.innerHTML=''; });
  el('emptyState').innerHTML = ''; el('emptyState').style.display='block';
  _enableBtn();
}

// ── Render ────────────────────────────────────────────────────
function _render(data) {
  var s = data.stats;

  // ── Big stat cards (totals) + small pills (w/ EE breakdown)
  var sr = el('statsRow');
  sr.innerHTML =
    '<div class="stat"><div class="stat-val">' + s.total_ees + '</div><div class="stat-label">Execution Envs</div></div>' +
    '<div class="stat"><div class="stat-val">' + s.total_orgs + '</div><div class="stat-label">Organizations</div>' +
      '<div class="stat-pills"><span class="stat-pill ok">' + s.orgs_with_ee + ' with EE</span>' +
      '<span class="stat-pill na">' + (s.total_orgs - s.orgs_with_ee) + ' without</span></div></div>' +
    '<div class="stat"><div class="stat-val">' + s.total_projects + '</div><div class="stat-label">Projects</div>' +
      '<div class="stat-pills"><span class="stat-pill ok">' + s.projects_with_ee + ' with EE</span>' +
      '<span class="stat-pill na">' + (s.total_projects - s.projects_with_ee) + ' without</span></div></div>' +
    '<div class="stat"><div class="stat-val">' + s.total_templates + '</div><div class="stat-label">Job Templates</div>' +
      '<div class="stat-pills"><span class="stat-pill ok">' + s.templates_with_ee + ' with EE</span>' +
      '<span class="stat-pill na">' + (s.total_templates - s.templates_with_ee) + ' without</span></div></div>';
  sr.style.display = 'grid';

  el('panel-ees').innerHTML       = _renderEEs(data.ees);
  el('panel-orgs').innerHTML      = _renderOrgs(data.orgs, s.total_orgs);
  el('panel-projects').innerHTML  = _renderProjects(data.projects, s.total_projects);
  el('panel-templates').innerHTML = _renderTemplates(data.templates, s.total_templates);

  el('emptyState').style.display = 'none';
  el('resTabs').style.display    = 'flex';
  el('exportBtn').style.display  = 'inline-block';
  _enableBtn();
  switchResTab(_activeRes);
}

function switchResTab(name) {
  _activeRes = name;
  ['ees','orgs','projects','templates'].forEach(function(t) {
    el('panel-'+t).classList.toggle('active', t===name);
    el('tab-'+t).classList.toggle('active', t===name);
  });
}

// ── Table renderers ───────────────────────────────────────────
function _renderEEs(ees) {
  var rows = ees.map(function(e) {
    return '<tr>'
      + '<td><span class="id-chip">#' + e.id + '</span></td>'
      + '<td><strong>' + esc(e.name) + '</strong></td>'
      + '<td><span class="image-text">' + esc(e.image) + '</span></td>'
      + '<td><span class="org-badge">' + esc(e.org) + '</span></td>'
      + '</tr>';
  }).join('');
  return _section('Execution Environments', ees.length, null, 'tbl-ees', 'Filter by name or image\u2026',
    '<table id="tbl-ees"><thead><tr><th>ID</th><th>Name</th><th>Image</th><th>Scope</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function _renderOrgs(orgs, total) {
  if (!orgs || !orgs.length) return '<div class="state">No organizations have an EE assigned.</div>';
  var rows = orgs.map(function(o) {
    return '<tr>'
      + '<td><span class="id-chip">#' + o.id + '</span></td>'
      + '<td><strong>' + esc(o.name) + '</strong></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(o.ee_name) + '</span></td>'
      + '</tr>';
  }).join('');
  return _section('Organizations', orgs.length, total, 'tbl-orgs', 'Filter by org or EE name\u2026',
    '<table id="tbl-orgs"><thead><tr><th>ID</th><th>Organization</th><th>Execution Environment</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function _renderProjects(projects, total) {
  if (!projects.length) return '<div class="state">No projects have an EE assigned.</div>';
  var rows = projects.map(function(p) {
    return '<tr>'
      + '<td><span class="id-chip">#' + p.id + '</span></td>'
      + '<td><strong>' + esc(p.name) + '</strong></td>'
      + '<td><span class="org-badge">' + esc(p.org_name || '\u2014') + '</span></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(p.ee_name) + '</span></td>'
      + '</tr>';
  }).join('');
  return _section('Projects', projects.length, total, 'tbl-projects', 'Filter by project, org or EE\u2026',
    '<table id="tbl-projects"><thead><tr><th>ID</th><th>Project</th><th>Organization</th><th>Execution Environment</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function _renderTemplates(templates, total) {
  if (!templates.length) return '<div class="state">No job templates have an EE assigned.</div>';
  var rows = templates.map(function(t) {
    return '<tr>'
      + '<td><span class="id-chip">#' + t.id + '</span></td>'
      + '<td><strong>' + esc(t.name) + '</strong></td>'
      + '<td><span class="org-badge">' + esc(t.org_name || '\u2014') + '</span></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(t.ee_name) + '</span></td>'
      + '</tr>';
  }).join('');
  return _section('Job Templates', templates.length, total, 'tbl-templates', 'Filter by template, org or EE\u2026',
    '<table id="tbl-templates"><thead><tr><th>ID</th><th>Template</th><th>Organization</th><th>Execution Environment</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function _section(title, count, total, tableId, placeholder, tableHtml) {
  var badge = total != null ? (count + ' of ' + total + ' have EE') : (count + ' total');
  return '<div class="section-meta"><h2>' + title + '</h2><span class="count-badge">' + badge + '</span></div>'
    + '<div class="search-wrap"><input class="search" placeholder="' + placeholder + '" oninput="filterTable(this,\'' + tableId + '\')"/></div>'
    + '<div class="table-wrap">' + tableHtml + '</div>';
}

// ── Env summary bar ───────────────────────────────────────────
async function _loadEnvSummary() {
  await loadEnvSummary(function(data) {
    _envStats = data;
    var bar = el('envStatsBar');
    if (!bar) return;
    var t = data.totals || {}, hosts = data.hosts || [];
    var online = hosts.filter(function(h){ return h.has_data; }).length;
    bar.innerHTML =
      '<span class="env-stats-label">' + esc(data.env_label) + ' totals</span>' +
      envStatChip(t.total_ees         || 0, 'EEs') +
      envStatChip(t.orgs_with_ee      || 0, 'Orgs w/ EE',      t.total_orgs) +
      envStatChip(t.projects_with_ee  || 0, 'Projects w/ EE',  t.total_projects) +
      envStatChip(t.templates_with_ee || 0, 'Templates w/ EE', t.total_templates) +
      '<span class="env-stats-hosts">' + online + ' / ' + hosts.length + ' hosts cached</span>';
    bar.style.display = 'flex';
  });
}

function triggerRefresh() { startRefresh('ee'); }

// ── CSV ───────────────────────────────────────────────────────
function exportCSV() {
  if (!_data) return;
  var env  = _envs.find(function(e){ return e.hosts.some(function(h){ return h.key===_activeHost; }); });
  var host = env && env.hosts.find(function(h){ return h.key===_activeHost; });
  var lines = ['Section,ID,Name,Image/EE,Org'];
  _data.ees.forEach(function(e)      { lines.push('EE,'        +e.id+',"'+e.name+'","'+e.image+'","'+e.org+'"'); });
  _data.projects.forEach(function(p) { lines.push('Project,'   +p.id+',"'+p.name+'","'+p.ee_name+'","'+(p.org_name||'')+'"'); });
  _data.templates.forEach(function(t){ lines.push('Template,'  +t.id+',"'+t.name+'","'+t.ee_name+'","'+(t.org_name||'')+'"'); });
  var a = document.createElement('a');
  a.href     = URL.createObjectURL(new Blob([lines.join('\n')],{type:'text/csv'}));
  a.download = 'ee-' + _activeHost + '.csv';
  a.click();
}

window.addEventListener('DOMContentLoaded', commonBoot);
