/* projects.js — Projects inventory (requires common.js) */
'use strict';

var _data        = null;
var _scmPatterns = [];
var _allOrgs     = [];
var _activeOrg   = null;

window._onHostReady = async function() {
  el('projectsContent').style.display = 'none';
  el('emptyState').style.display = 'block';
  el('emptyState').innerHTML = '<span class="spinner"></span>';
  renderSyncedBar(null);
  // Load config once
  if (!_scmPatterns.length) {
    try {
      var cr = await fetch('/api/config');
      var cd = await cr.json();
      _scmPatterns = cd.scm_url_patterns || [];
    } catch(e) {}
  }
  await _load();
};

async function _load(force) {
  try {
    var url  = '/api/projects/full?host=' + enc(_activeHost) + (force ? '&force=true' : '');
    var res  = await fetch(url);
    var data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed');
    _data = data;
    _render(data);
    renderSyncedBar(data.synced_at);
  } catch(e) {
    el('emptyState').innerHTML = '&#x2717; ' + esc(e.message);
    el('emptyState').style.display = 'block';
    el('projectsContent').style.display = 'none';
    renderSyncedBar(null);
    _enableBtn();
  }
}

async function triggerRefresh() {
  var btn = el('forceBtn');
  btn.disabled = true; btn.textContent = '\u21ba Refreshing\u2026';
  await _load(true);
  btn.disabled = false; btn.textContent = '\u21ba Refresh from AAP';
}

function _render(data) {
  var projects = data.results || [];
  if (!projects.length) {
    el('emptyState').innerHTML = 'No projects found.';
    el('emptyState').style.display = 'block';
    el('projectsContent').style.display = 'none';
    _enableBtn();
    return;
  }

  el('emptyState').style.display      = 'none';
  el('projectsContent').style.display = 'block';

  // ── Stat cards ────────────────────────────────────────────
  // SCM pattern cards (dynamic from config)
  var scmCards = '';
  _scmPatterns.forEach(function(p) {
    var count = projects.filter(function(pr){
      return pr.scm_url && pr.scm_url.toLowerCase().includes(p.pattern.toLowerCase());
    }).length;
    scmCards += '<div class="stat"><div class="stat-val">' + count + '</div><div class="stat-label">' + esc(p.label) + '</div></div>';
  });

  // Status breakdown card
  var statusCounts = {};
  projects.forEach(function(p){
    var s = p.status || 'unknown';
    statusCounts[s] = (statusCounts[s]||0) + 1;
  });
  var statusPills = Object.keys(statusCounts).map(function(s){
    return '<span class="stat-pill status-pill-' + s + '">' + s + ': ' + statusCounts[s] + '</span>';
  }).join('');
  var statusCard = '<div class="stat"><div class="stat-val">' + Object.keys(statusCounts).length + '</div>'
    + '<div class="stat-label">Status Types</div>'
    + '<div class="stat-pills">' + statusPills + '</div></div>';

  // Created-by breakdown card
  var userCounts = {};
  projects.forEach(function(p){ if(p.created_by){ userCounts[p.created_by]=(userCounts[p.created_by]||0)+1; } });
  var topUsers = Object.keys(userCounts).sort(function(a,b){ return userCounts[b]-userCounts[a]; }).slice(0,3);
  var userPills = topUsers.map(function(u){
    return '<span class="stat-pill">' + esc(u) + ': ' + userCounts[u] + '</span>';
  }).join('');
  var userCard = '<div class="stat"><div class="stat-val">' + Object.keys(userCounts).length + '</div>'
    + '<div class="stat-label">Contributors</div>'
    + '<div class="stat-pills">' + userPills + '</div></div>';

  var statsHtml =
    '<div class="stats" style="margin-bottom:20px">'
    + '<div class="stat"><div class="stat-val">' + projects.length + '</div><div class="stat-label">Total Projects</div></div>'
    + scmCards
    + statusCard
    + userCard
    + '</div>';

  // ── Org filter pills ──────────────────────────────────────
  _allOrgs = [];
  projects.forEach(function(p){ if(p.org_name && !_allOrgs.includes(p.org_name)) _allOrgs.push(p.org_name); });
  _allOrgs.sort();

  var orgPills = '<div class="org-filter-bar">'
    + '<button class="org-pill' + (_activeOrg===null?' active':'') + '" onclick="_filterOrg(null)">All</button>'
    + _allOrgs.map(function(o){
        return '<button class="org-pill' + (_activeOrg===o?' active':'') + '" onclick="_filterOrg(\'' + esc(o) + '\')">' + esc(o) + '</button>';
      }).join('')
    + '</div>';

  // ── Table ─────────────────────────────────────────────────
  var rows = projects.map(function(p) {
    var scmHtml = p.scm_url
      ? '<span class="mono-val scm-url" title="' + esc(p.scm_url) + '">' + esc(p.scm_url.replace(/^https?:\/\//,'')) + '</span>'
        + (p.scm_branch ? ' <span class="type-badge">' + esc(p.scm_branch) + '</span>' : '')
      : '<span class="na">\u2014</span>';
    var eeHtml     = p.ee_name   ? '<span class="ee-tag"><span class="dot"></span>' + esc(p.ee_name) + '</span>' : '<span class="na">\u2014</span>';
    var statusHtml = p.status    ? '<span class="status-chip status-' + esc(p.status) + '">' + esc(p.status) + '</span>' : '<span class="na">\u2014</span>';
    var orgHtml    = p.org_name  ? '<span class="org-badge">' + esc(p.org_name) + '</span>' : '<span class="na">\u2014</span>';
    var userHtml   = p.created_by? '<span class="user-badge">' + esc(p.created_by) + '</span>' : '<span class="na">\u2014</span>';
    return '<tr data-org="' + esc(p.org_name||'') + '">'
      + '<td><span class="id-chip">' + p.id + '</span></td>'
      + '<td><strong>' + esc(p.name) + '</strong></td>'
      + '<td>' + orgHtml + '</td>'
      + '<td>' + scmHtml + '</td>'
      + '<td>' + eeHtml + '</td>'
      + '<td>' + statusHtml + '</td>'
      + '<td>' + userHtml + '</td>'
      + '</tr>';
  }).join('');

  el('projectsContent').innerHTML =
    statsHtml + orgPills
    + '<div class="section-meta" style="margin-top:16px"><h2>Projects</h2><span class="count-badge">' + projects.length + ' total</span></div>'
    + '<div class="search-wrap"><input class="search" id="projFilter" placeholder="Filter by name, org, URL or user\u2026"></div>'
    + '<div class="table-wrap"><table id="projTable">'
    + '<thead><tr><th>ID</th><th>Name</th><th>Org</th><th>SCM URL</th><th>EE</th><th>Status</th><th>Created By</th></tr></thead>'
    + '<tbody>' + rows + '</tbody></table></div>';

  var f = el('projFilter');
  if (f) f.oninput = function(){ _applyFilters(); };

  _enableBtn();
}

function _filterOrg(org) {
  _activeOrg = org;
  document.querySelectorAll('.org-pill').forEach(function(b){
    var matches = org === null ? b.textContent === 'All' : b.textContent === org;
    b.classList.toggle('active', matches);
  });
  _applyFilters();
}

function _applyFilters() {
  var q   = (el('projFilter') ? el('projFilter').value : '').toLowerCase();
  document.querySelectorAll('#projTable tbody tr').forEach(function(row){
    var orgMatch  = _activeOrg === null || row.dataset.org === _activeOrg;
    var textMatch = !q || row.textContent.toLowerCase().includes(q);
    row.style.display = (orgMatch && textMatch) ? '' : 'none';
  });
}

function exportCSV() {
  if (!_data) return;
  var rows = [['ID','Name','Org','SCM Type','SCM URL','Branch','EE','Status','Created By']];
  (_data.results||[]).forEach(function(p){
    rows.push([p.id,p.name,p.org_name,p.scm_type,p.scm_url,p.scm_branch,p.ee_name,p.status,p.created_by]);
  });
  var csv  = rows.map(function(r){ return r.map(function(c){ return '"'+String(c||'').replace(/"/g,'""')+'"'; }).join(','); }).join('\r\n');
  var blob = new Blob([csv],{type:'text/csv'});
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href=url; a.download='projects.csv'; a.click();
  URL.revokeObjectURL(url);
}

window.addEventListener('DOMContentLoaded', commonBoot);
