/* ssl.js — SSL certificate checker (no common.js nav — all-hosts view) */
'use strict';

var _data = null;

function el(id) { return document.getElementById(id); }
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function _renderSyncedBar(isoStr) {
  var bar = el('syncedBar');
  if (!bar) return;
  if (!isoStr) { bar.style.display='none'; return; }
  var d   = new Date(isoStr);
  var age = Math.round((Date.now()-d.getTime())/1000);
  var ago = age<60 ? age+'s ago' : age<3600 ? Math.round(age/60)+'m ago' : Math.round(age/3600)+'h ago';
  bar.innerHTML = '<span class="synced-dot fresh"></span><strong>Cached</strong> \u00b7 last checked <strong>' + ago + '</strong> <span class="synced-date">(' + d.toLocaleDateString() + ' ' + d.toLocaleTimeString() + ')</span>';
  bar.style.display = 'flex';
}

async function boot() {
  el('emptyState').innerHTML = '<span class="spinner"></span>';
  try {
    var res  = await fetch('/api/ssl');
    var data = await res.json();
    if (!data.success) throw new Error(data.error||'Failed');
    if (!data.results || !data.results.length) {
      el('emptyState').innerHTML =
        '<div style="text-align:center;padding:40px 0">'
        + '<div style="font-size:.9rem;font-weight:600;margin-bottom:8px">No certificate data yet</div>'
        + '<div style="color:var(--muted);font-size:.82rem">Press <strong>Check All Hosts</strong> to run the first scan</div>'
        + '</div>';
      return;
    }
    _data = data;
    _render(data);
  } catch(e) {
    el('emptyState').innerHTML = '&#x2717; ' + esc(e.message);
  }
}

async function triggerRefresh() {
  var btn = el('refreshBtn');
  btn.disabled = true; btn.textContent = '\u21ba Checking\u2026';
  _renderSyncedBar(null);
  try {
    var res  = await fetch('/api/ssl?force=true');
    var data = await res.json();
    if (!data.success) throw new Error(data.error||'Failed');
    _data = data; _render(data);
  } catch(e) {
    el('emptyState').innerHTML = '&#x2717; ' + esc(e.message);
    el('sslContent').style.display = 'none';
    el('emptyState').style.display = 'block';
  } finally {
    btn.disabled = false; btn.textContent = '\u21ba Check All Hosts';
  }
}

function _render(data) {
  el('emptyState').style.display = 'none';
  el('sslContent').style.display = 'block';
  _renderSyncedBar(data.checked_at);

  var results = (data.results||[]).slice().sort(function(a,b){
    var o={expired:0,critical:1,warning:2,error:3,unknown:4,ok:5};
    return (o[a.status]||99)-(o[b.status]||99);
  });
  var s = data.summary||{};

  var html =
    '<div class="stats" style="margin-bottom:24px">'
    + _sc(results.length,   'Hosts Checked')
    + _sc(s.ok       ||0,   'Valid')
    + _sc(s.warning  ||0,   'Expiring Soon')
    + _sc(s.critical ||0,   'Critical')
    + _sc(s.expired  ||0,   'Expired')
    + _sc(s.error    ||0,   'Unreachable')
    + '</div>';

  var rows = results.map(function(r) {
    var daysCell = r.days_left!=null
      ? '<span class="days-'+r.status+'">'+(r.days_left<0?'Expired '+Math.abs(r.days_left)+'d ago':r.days_left+' days')+'</span>'
      : '<span class="na">\u2014</span>';
    var cnCell     = r.cn ? '<span class="mono-val">'+esc(r.cn)+'</span>' : (r.error ? '<span class="na">'+esc(r.error)+'</span>' : '<span class="na">\u2014</span>');
    var sansCell   = r.sans&&r.sans.length ? r.sans.slice(0,3).map(function(s){ return '<span class="group-tag">'+esc(s)+'</span>'; }).join(' ')+(r.sans.length>3?' <span class="na">+'+(r.sans.length-3)+'</span>':'') : '<span class="na">\u2014</span>';
    var issuerCell = r.issuer_cn ? '<span class="mono-val">'+esc(r.issuer_cn)+'</span>'+(r.issuer_org?'<br><span class="na">'+esc(r.issuer_org)+'</span>':'') : '<span class="na">\u2014</span>';
    var serialCell = r.serial ? '<span class="mono-val serial-val" title="'+esc(r.serial)+'">'+esc(String(r.serial))+'</span>' : '<span class="na">\u2014</span>';
    return '<tr class="row-'+r.status+'">'
      + '<td><span class="env-label-badge">'+esc(r.env_label)+'</span></td>'
      + '<td><strong>'+esc(r.host_label)+'</strong><br><span class="na">'+esc(r.hostname)+'</span></td>'
      + '<td><span class="status-chip ssl-'+r.status+'">'+_statusLabel(r.status)+'</span></td>'
      + '<td>'+daysCell+'</td>'
      + '<td>'+(r.expires?'<span class="mono-val">'+esc(_fmtDate(r.expires))+'</span>':'<span class="na">\u2014</span>')+'</td>'
      + '<td>'+cnCell+'</td>'
      + '<td>'+sansCell+'</td>'
      + '<td>'+issuerCell+'</td>'
      + '<td>'+serialCell+'</td>'
      + '</tr>';
  }).join('');

  html += '<div class="section-meta"><h2>Certificate Status</h2><span class="count-badge">'+results.length+' hosts</span></div>'
    + '<div class="search-wrap"><input class="search" id="sslFilter" placeholder="Filter by host, env, CN or issuer\u2026"></div>'
    + '<div class="table-wrap"><table id="sslTable">'
    + '<thead><tr><th>Env</th><th>Host</th><th>Status</th><th>Days Left</th><th>Expires</th><th>CN</th><th>SANs</th><th>Issuer</th><th>Serial</th></tr></thead>'
    + '<tbody>'+rows+'</tbody></table></div>';

  el('sslContent').innerHTML = html;
  var f = el('sslFilter');
  if (f) f.oninput = function(){ _filter(this.value); };
}

function _statusLabel(s) {
  return {ok:'\u2713 Valid',warning:'\u26a0 Expiring',critical:'\u26a0 Critical',expired:'\u2717 Expired',error:'\u2717 Error',unknown:'? Unknown'}[s]||s;
}
function _fmtDate(d) {
  try { return new Date(d).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}); } catch(e){ return d; }
}
function _sc(val, label) {
  return '<div class="stat"><div class="stat-val">'+val+'</div><div class="stat-label">'+label+'</div></div>';
}
function _filter(q) {
  q = q.toLowerCase();
  document.querySelectorAll('#sslTable tbody tr').forEach(function(r){ r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'; });
}
function exportCSV() {
  if (!_data) return;
  var rows=[['Env','Host','Hostname','Status','Days Left','Expires','Issued','CN','SANs','Issuer CN','Issuer Org','Serial']];
  (_data.results||[]).forEach(function(r){
    rows.push([r.env_label,r.host_label,r.hostname,r.status,r.days_left!==undefined?r.days_left:'',r.expires||'',r.issued||'',r.cn||'',(r.sans||[]).join(' | '),r.issuer_cn||'',r.issuer_org||'',r.serial||'']);
  });
  var csv=rows.map(function(r){return r.map(function(c){return '"'+String(c||'').replace(/"/g,'""')+'"';}).join(',');}).join('\r\n');
  var blob=new Blob([csv],{type:'text/csv'}); var url=URL.createObjectURL(blob);
  var a=document.createElement('a'); a.href=url; a.download='ssl-certs.csv'; a.click(); URL.revokeObjectURL(url);
}
window.addEventListener('DOMContentLoaded', boot);
