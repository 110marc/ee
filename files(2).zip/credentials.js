/* credentials.js — Credentials (requires common.js) */
'use strict';

var _data         = null;
var _watchUsers   = [];
var _envStats     = null;

window._onHostReady = async function() {
  el('credPanel').innerHTML = '';
  el('statsRow').style.display = 'none';
  el('emptyState').style.display = 'block';
  el('emptyState').innerHTML = '<span class="spinner"></span>';
  renderSyncedBar(null);
  // Load config on first run
  if (!_watchUsers.length) {
    try {
      var cr = await fetch('/api/config');
      var cd = await cr.json();
      _watchUsers = (cd.credential_watch_users || []).map(function(u){ return u.toLowerCase(); });
    } catch(e) {}
  }
  await Promise.all([_load(), _loadEnvSummary()]);
};
window._onEnvChange = function() {
  _envStats = null;
  var bar = el('envStatsBar'); if(bar) bar.style.display='none';
};

async function _load() {
  try {
    var res  = await fetch('/api/summary?host=' + enc(_activeHost));
    var data = await res.json();
    if (data.success && data.credentials && data.credentials.length) {
      _data = data;
      _render(data);
      renderSyncedBar(data.synced_at);
    } else {
      el('emptyState').innerHTML   = 'No cached data \u2014 press <strong>\u21ba Refresh from AAP</strong>';
      el('emptyState').style.display = 'block';
      el('statsRow').style.display = 'none';
      renderSyncedBar(null);
      _enableBtn();
    }
  } catch(e) {
    el('emptyState').innerHTML   = '&#x2717; ' + esc(e.message);
    el('emptyState').style.display = 'block';
    renderSyncedBar(null);
    _enableBtn();
  }
}

function _render(data) {
  var creds = data.credentials || [];
  if (!creds.length) {
    el('emptyState').innerHTML = 'No credentials found.';
    el('emptyState').style.display = 'block';
    el('statsRow').style.display = 'none';
    return;
  }

  // ── Stat cards ────────────────────────────────────────────
  var sr = el('statsRow');
  var statsHtml = '<div class="stat"><div class="stat-val">' + creds.length + '</div><div class="stat-label">Total Credentials</div></div>';

  // Dynamic watch-user cards from config
  _watchUsers.forEach(function(watch) {
    var count = creds.filter(function(c){
      return c.username && c.username.toLowerCase().includes(watch);
    }).length;
    statsHtml += '<div class="stat"><div class="stat-val">' + count + '</div><div class="stat-label">Username: ' + esc(watch) + '</div></div>';
  });

  sr.innerHTML = statsHtml;
  sr.style.display = 'grid';

  el('emptyState').style.display = 'none';
  el('credPanel').innerHTML = _renderTable(creds);
}

function _renderTable(creds) {
  var rows = creds.map(function(c) {
    var org      = c.org_name ? '<span class="org-badge">' + esc(c.org_name) + '</span>' : '<span class="na">global</span>';
    var username = c.username ? '<span class="id-chip">' + esc(c.username) + '</span>' : '<span class="na">\u2014</span>';
    var created  = c.created  ? '<span class="mono-val">' + fmtDate(c.created)  + '</span>' : '<span class="na">\u2014</span>';
    var modified = c.modified ? '<span class="mono-val">' + fmtDate(c.modified) + '</span>' : '<span class="na">\u2014</span>';
    return '<tr>'
      + '<td><span class="id-chip">#' + c.id + '</span></td>'
      + '<td><strong>' + esc(c.name) + '</strong>'
      + (c.description ? '<br><span class="row-sub">' + esc(c.description) + '</span>' : '')
      + '</td>'
      + '<td>' + org + '</td>'
      + '<td><span class="type-badge">' + esc(c.ctype_name || '\u2014') + '</span></td>'
      + '<td>' + username + '</td>'
      + '<td>' + created  + '</td>'
      + '<td>' + modified + '</td>'
      + '</tr>';
  }).join('');

  return '<div class="section-meta"><h2>Credentials</h2><span class="count-badge">' + creds.length + ' total</span></div>'
    + '<div class="search-wrap"><input class="search" placeholder="Filter by name, org or type\u2026" oninput="filterTable(this,\'tbl-creds\')"/></div>'
    + '<div class="table-wrap"><table id="tbl-creds">'
    + '<thead><tr><th>ID</th><th>Name</th><th>Organization</th><th>Type</th><th>Username</th><th>Created</th><th>Modified</th></tr></thead>'
    + '<tbody>' + rows + '</tbody></table></div>';
}

async function _loadEnvSummary() {
  await loadEnvSummary(function(data) {
    _envStats = data;
    var bar = el('envStatsBar'); if (!bar) return;
    var t = data.totals || {}, hosts = data.hosts || [];
    var online = hosts.filter(function(h){ return h.has_data; }).length;
    bar.innerHTML =
      '<span class="env-stats-label">' + esc(data.env_label) + ' totals</span>' +
      envStatChip(t.total_credentials  || 0, 'Credentials') +
      envStatChip(t.org_credentials    || 0, 'Org',    t.total_credentials) +
      envStatChip(t.global_credentials || 0, 'Global', t.total_credentials) +
      '<span class="env-stats-hosts">' + online + ' / ' + hosts.length + ' hosts cached</span>';
    bar.style.display = 'flex';
  });
}

function triggerRefresh() { startRefresh('credentials'); }

window.addEventListener('DOMContentLoaded', commonBoot);
