/* ldap.js — LDAP settings + org mapping (requires common.js) */
'use strict';

var _data = null;

window._onHostReady = async function() {
  el('ldapContent').style.display = 'none';
  el('emptyState').innerHTML = '<span class="spinner"></span>';
  el('emptyState').style.display = 'block';
  renderSyncedBar(null);
  await _load();
};

async function _load(force) {
  try {
    var url  = '/api/ldap?host=' + enc(_activeHost) + (force ? '&force=true' : '');
    var res  = await fetch(url);
    var data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed');
    _data = data;
    _render(data);
    renderSyncedBar(data.synced_at);
  } catch(e) {
    el('emptyState').innerHTML = '&#x2717; ' + esc(e.message);
    el('emptyState').style.display = 'block';
    el('ldapContent').style.display = 'none';
    renderSyncedBar(null);
    _enableBtn();
  }
}

async function triggerRefresh() {
  var btn = el('forceBtn');
  btn.disabled = true; btn.textContent = '\u21ba Refreshing\u2026';
  await _load(true);
  btn.disabled = false; btn.textContent = '\u21ba Refresh from AAP';
}

function _render(data) {
  if (!data.configured) {
    el('emptyState').innerHTML = 'No LDAP configuration on this host.';
    el('emptyState').style.display = 'block';
    el('ldapContent').style.display = 'none';
    return;
  }

  el('emptyState').style.display  = 'none';
  el('ldapContent').style.display = 'block';

  var mappedCount   = (data.mapped_orgs   || []).length;
  var unmappedCount = (data.unmapped_orgs || []).length;
  var teamCount     = Object.keys(data.team_map || {}).length;

  // ── Stat cards ────────────────────────────────────────────
  var html =
    '<div class="stats" style="margin-bottom:24px">'
    + '<div class="stat"><div class="stat-val">' + mappedCount   + '</div><div class="stat-label">Orgs Mapped</div></div>'
    + '<div class="stat"><div class="stat-val">' + unmappedCount + '</div><div class="stat-label">Orgs Unmapped</div></div>'
    + '<div class="stat"><div class="stat-val">' + teamCount     + '</div><div class="stat-label">Team Maps</div></div>'
    + '</div>';

  // ── Settings ──────────────────────────────────────────────
  var categories = data.categories || {};
  var catNames   = Object.keys(categories);
  if (catNames.length) {
    html += '<div class="ldap-block">';
    html += '<div class="section-meta" style="margin-bottom:16px"><h2>Settings</h2></div>';
    catNames.forEach(function(cat) {
      var rows = categories[cat].filter(function(r){ return r.value !== null && r.value !== undefined && r.value !== ''; });
      if (!rows.length) return;
      html += '<div class="cat-label">' + esc(cat) + '</div>';
      html += '<div class="info-grid" style="margin-bottom:14px">';
      rows.forEach(function(row) {
        html += '<div class="info-row">'
          + '<span class="info-label">' + esc(row.key) + '</span>'
          + '<span class="info-value">' + _fmtVal(row.value) + '</span>'
          + '</div>';
      });
      html += '</div>';
    });
    html += '</div>';
  }

  // ── Org map table ─────────────────────────────────────────
  html += _renderOrgMap(data);
  el('ldapContent').innerHTML = html;
}

function _renderOrgMap(data) {
  var orgMap       = data.org_map       || {};
  var mappedOrgs   = data.mapped_orgs   || [];
  var unmappedOrgs = data.unmapped_orgs || [];
  var total        = mappedOrgs.length + unmappedOrgs.length;
  var rows = '';

  mappedOrgs.forEach(function(n) {
    var m = orgMap[n] || {};
    rows += '<tr>'
      + '<td><span class="org-name">' + esc(n) + '</span></td>'
      + '<td><span class="mapped-badge">&#x2713; Mapped</span></td>'
      + '<td>' + _groupTags(_extractGroups(m.admins)) + '</td>'
      + '<td>' + _groupTags(_extractGroups(m.users))  + '</td>'
      + '<td>' + (m.remove_admins ? '<span class="type-badge">Yes</span>' : '<span class="na">No</span>') + '</td>'
      + '<td>' + (m.remove_users  ? '<span class="type-badge">Yes</span>' : '<span class="na">No</span>') + '</td>'
      + '</tr>';
  });

  unmappedOrgs.forEach(function(n) {
    rows += '<tr>'
      + '<td><span class="org-name muted">' + esc(n) + '</span></td>'
      + '<td><span class="na">No mapping</span></td>'
      + '<td colspan="4"><span class="na">\u2014</span></td>'
      + '</tr>';
  });

  if (!rows) rows = '<tr><td colspan="6" class="state" style="padding:32px">No organizations in cache \u2014 refresh EE first.</td></tr>';

  return '<div class="ldap-block">'
    + '<div class="section-meta"><h2>Organization Map</h2>'
    + '<span class="count-badge">' + mappedOrgs.length + ' of ' + total + ' orgs mapped</span></div>'
    + '<div class="table-wrap"><table id="orgTable">'
    + '<thead><tr><th>Organization</th><th>Status</th><th>Admin Groups</th><th>User Groups</th><th>Remove Admins</th><th>Remove Members</th></tr></thead>'
    + '<tbody>' + rows + '</tbody></table></div></div>';
}

function _fmtVal(val) {
  if (val === null || val === undefined || val === '') return '<span class="na">not set</span>';
  if (typeof val === 'boolean') return val ? '<span class="mapped-badge">&#x2713; Yes</span>' : '<span class="na">No</span>';
  if (Array.isArray(val)) {
    if (!val.length) return '<span class="na">empty</span>';
    return val.map(function(v){ return '<span class="group-tag">' + esc(Array.isArray(v) ? v.join(' ') : String(v)) + '</span>'; }).join(' ');
  }
  if (typeof val === 'object') return '<span class="mono-val">' + esc(JSON.stringify(val)) + '</span>';
  return '<span class="mono-val">' + esc(String(val)) + '</span>';
}

function _extractGroups(val) {
  if (!val) return [];
  if (typeof val === 'string') return [val];
  if (Array.isArray(val)) return val.filter(function(v){ return typeof v === 'string'; });
  if (typeof val === 'object') {
    var g = val.ldap_groups || val.has_ldap_group || val.group_dn || '';
    if (typeof g === 'string' && g) return [g];
    if (Array.isArray(g)) return g;
  }
  return [];
}

function _groupTags(groups) {
  if (!groups || !groups.length) return '<span class="na">\u2014</span>';
  return groups.map(function(g) {
    var m = g.match(/CN=([^,]+)/i);
    return '<span class="group-tag" title="' + esc(g) + '">' + esc(m ? m[1] : g) + '</span>';
  }).join(' ');
}

function exportCSV() {
  if (!_data) return;
  var orgMap = _data.org_map || {};
  var rows   = [['Organization','Status','Admin Groups','User Groups','Remove Admins','Remove Members']];
  (_data.mapped_orgs||[]).forEach(function(n){
    var m = orgMap[n]||{};
    rows.push([n,'Mapped',
      _extractGroups(m.admins).map(function(g){ var x=g.match(/CN=([^,]+)/i); return x?x[1]:g; }).join(' | '),
      _extractGroups(m.users).map(function(g){  var x=g.match(/CN=([^,]+)/i); return x?x[1]:g; }).join(' | '),
      m.remove_admins?'Yes':'No', m.remove_users?'Yes':'No']);
  });
  (_data.unmapped_orgs||[]).forEach(function(n){ rows.push([n,'No mapping','','','','']); });
  var csv  = rows.map(function(r){ return r.map(function(c){ return '"'+String(c||'').replace(/"/g,'""')+'"'; }).join(','); }).join('\r\n');
  var blob = new Blob([csv],{type:'text/csv'});
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href=url; a.download='ldap-org-map.csv'; a.click();
  URL.revokeObjectURL(url);
}

window.addEventListener('DOMContentLoaded', commonBoot);
