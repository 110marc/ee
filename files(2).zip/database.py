"""
database.py
SQLite-backed cache layer.

Schema: one table per resource type, keyed by host_key.
Each row stores the full JSON payload + fetched_at timestamp.

                ┌──────────────────────────────────────┐
                │  cache                               │
                ├──────────┬────────────┬──────────────┤
                │ host_key │ resource   │ data (JSON)  │
                │          │            │ fetched_at   │
                └──────────┴────────────┴──────────────┘

resource values: "execution_environments" | "projects" | "job_templates"
"""

import sqlite3
import json
import time
from contextlib import contextmanager
from datetime import datetime, timezone

import config

DB_PATH = getattr(config, "DB_PATH", "aap_cache.db")
TTL_SECONDS = getattr(config, "CACHE_TTL_MINUTES", 30) * 60


# ── Schema ────────────────────────────────────────────────────

def init_db():
    """Create tables if they don't exist. Safe to call on every startup."""
    with _connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                host_key   TEXT    NOT NULL,
                resource   TEXT    NOT NULL,
                data       TEXT    NOT NULL,
                fetched_at REAL    NOT NULL,
                PRIMARY KEY (host_key, resource)
            )
        """)
        conn.commit()


@contextmanager
def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


# ── Read ──────────────────────────────────────────────────────

def get_cached(host_key: str, resource: str, ignore_ttl: bool = False) -> tuple[list | None, datetime | None]:
    """
    Returns (data, fetched_at) if a cache entry exists.
    Returns (None, None) only when no entry exists at all.

    By default respects TTL — returns (None, None) for stale entries so
    the service layer knows to re-fetch. Pass ignore_ttl=True to always
    return data (used by /api/summary to show last-known data to the UI).
    """
    with _connect() as conn:
        row = conn.execute(
            "SELECT data, fetched_at FROM cache WHERE host_key=? AND resource=?",
            (host_key, resource)
        ).fetchone()

    if row is None:
        return None, None

    fetched_at = datetime.fromtimestamp(row["fetched_at"], tz=timezone.utc)
    age = time.time() - row["fetched_at"]

    if not ignore_ttl and age > TTL_SECONDS:
        return None, None  # stale — caller should re-fetch

    return json.loads(row["data"]), fetched_at


# ── Write ─────────────────────────────────────────────────────

def set_cached(host_key: str, resource: str, data: list):
    """Insert or replace a cache entry with current timestamp."""
    with _connect() as conn:
        conn.execute(
            """
            INSERT INTO cache (host_key, resource, data, fetched_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(host_key, resource) DO UPDATE SET
                data       = excluded.data,
                fetched_at = excluded.fetched_at
            """,
            (host_key, resource, json.dumps(data), time.time())
        )
        conn.commit()


# ── Invalidate ────────────────────────────────────────────────

def invalidate(host_key: str, resource: str | None = None):
    """
    Delete cache entries for a host.
    If resource is given, only that resource is cleared.
    If resource is None, all resources for the host are cleared.
    """
    with _connect() as conn:
        if resource:
            conn.execute(
                "DELETE FROM cache WHERE host_key=? AND resource=?",
                (host_key, resource)
            )
        else:
            conn.execute("DELETE FROM cache WHERE host_key=?", (host_key,))
        conn.commit()


def invalidate_all():
    """Wipe the entire cache across all hosts."""
    with _connect() as conn:
        conn.execute("DELETE FROM cache")
        conn.commit()


# ── Status ────────────────────────────────────────────────────

def cache_status() -> list[dict]:
    """
    Returns metadata about all cached entries — used by /api/cache.
    Never returns actual data payloads.
    """
    now = time.time()
    with _connect() as conn:
        rows = conn.execute(
            "SELECT host_key, resource, fetched_at FROM cache ORDER BY host_key, resource"
        ).fetchall()

    results = []
    for row in rows:
        age_seconds = now - row["fetched_at"]
        fetched_dt  = datetime.fromtimestamp(row["fetched_at"], tz=timezone.utc)
        results.append({
            "host_key":   row["host_key"],
            "resource":   row["resource"],
            "fetched_at": fetched_dt.isoformat(),
            "age_seconds": round(age_seconds),
            "ttl_seconds": TTL_SECONDS,
            "fresh":       age_seconds <= TTL_SECONDS,
            "expires_in":  max(0, round(TTL_SECONDS - age_seconds)),
        })
    return results
