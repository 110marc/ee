"""
aap_client.py
Low-level AAP API client.

Supports a two-level config hierarchy: ENVIRONMENTS -> hosts.
At startup a flat registry of AAPClient instances is built,
keyed by host_key (unique across all environments).

Consumers only ever call get_client(host_key).
"""

from __future__ import annotations
from typing import Optional
import requests
import urllib3
import config

urllib3.disable_warnings()


class AAPClient:

    def __init__(self, host_key: str, env_key: str, host_cfg: dict) -> None:
        self.host_key  = host_key
        self.env_key   = env_key
        self.env_label = config.ENVIRONMENTS[env_key]["label"]
        self.label     = host_cfg["label"]
        self.base_url  = host_cfg["url"].rstrip("/")
        self.auth      = (host_cfg["username"], host_cfg["password"])
        self.verify    = host_cfg.get("verify_ssl", False)
        self.timeout   = config.TIMEOUT
        self.page_size = config.PAGE_SIZE

    def get(self, endpoint: str) -> dict:
        """Single GET request. Returns parsed JSON."""
        url  = f"{self.base_url}{endpoint}"
        resp = requests.get(
            url,
            auth=self.auth,
            verify=self.verify,
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def get_all(self, endpoint: str) -> list:
        """
        Fetches ALL pages from a paginated AAP endpoint.
        Handles both absolute and relative 'next' URLs.
        """
        results = []
        url = f"{self.base_url}{endpoint}?page_size={self.page_size}"

        while url:
            resp = requests.get(
                url,
                auth=self.auth,
                verify=self.verify,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            results.extend(data.get("results", []))

            next_url = data.get("next")
            if next_url and next_url.startswith("/"):
                next_url = f"{self.base_url}{next_url}"
            url = next_url

        return results


def _build_registry() -> dict:
    """
    Builds a flat {host_key: AAPClient} registry from the
    two-level ENVIRONMENTS config. Raises on duplicate host keys.
    """
    registry = {}
    for env_key, env in config.ENVIRONMENTS.items():
        for host_key, host_cfg in env["hosts"].items():
            if host_key in registry:
                raise ValueError(
                    f"Duplicate host_key '{host_key}' in environment '{env_key}'. "
                    "All host keys must be unique across environments."
                )
            registry[host_key] = AAPClient(host_key, env_key, host_cfg)
    return registry


# Built once at import time
_clients = _build_registry()


def get_client(host_key: Optional[str] = None) -> AAPClient:
    """
    Returns the AAPClient for the given host key.
    Falls back to DEFAULT_HOST if host_key is None.
    """
    key = host_key or config.DEFAULT_HOST
    if key not in _clients:
        raise ValueError(
            f"Unknown host '{key}'. Known hosts: {list(_clients.keys())}"
        )
    return _clients[key]


def list_environments() -> list:
    """
    Returns the full env -> hosts tree without credentials.
    Used by /api/hosts so the UI can build the two-level selector.
    """
    result = []
    for env_key, env in config.ENVIRONMENTS.items():
        hosts = []
        for host_key, host_cfg in env["hosts"].items():
            hosts.append({
                "key":   host_key,
                "label": host_cfg["label"],
                "url":   host_cfg["url"],
            })
        result.append({
            "key":           env_key,
            "label":         env["label"],
            "allow_refresh": env.get("allow_refresh", True),
            "hosts":         hosts,
        })
    return result
