# ── AAP Dashboard Configuration ───────────────────────────────
#
# Two-level hierarchy:  ENVIRONMENTS  →  hosts within each env
#
# ENVIRONMENTS keys are env identifiers (e.g. "production")
# Each env has:
#   label  - display name shown in the UI env tab
#   hosts  - dict of host_key → host config
#
# host_key must be unique across ALL environments.
# It is used as the ?host= param in API calls.

ENVIRONMENTS = {
    "production": {
        "label":          "Production",
        "allow_refresh":  False,
        "hosts": {
            "prod-us": {
                "label":      "US East",
                "url":        "https://aap-prod-us.example.com",
                "username":   "admin",
                "password":   "prod-us-password",
                "verify_ssl": False,
            },
            "prod-eu": {
                "label":      "EU West",
                "url":        "https://aap-prod-eu.example.com",
                "username":   "admin",
                "password":   "prod-eu-password",
                "verify_ssl": False,
            },
        },
    },
    "staging": {
        "label":         "Staging",
        "allow_refresh": False,
        "hosts": {
            "staging-us": {
                "label":      "US Staging",
                "url":        "https://aap-staging-us.example.com",
                "username":   "admin",
                "password":   "staging-password",
                "verify_ssl": False,
            },
            "staging-eu": {
                "label":      "EU Staging",
                "url":        "https://aap-staging-eu.example.com",
                "username":   "admin",
                "password":   "staging-eu-password",
                "verify_ssl": False,
            },
        },
    },
    "dev": {
        "label":         "Dev",
        "allow_refresh": True,
        "hosts": {
            "dev-local": {
                "label":      "Local Dev",
                "url":        "https://aap-dev.example.com",
                "username":   "admin",
                "password":   "dev-password",
                "verify_ssl": False,
            },
        },
    },
}

# Default env + host shown on first load
DEFAULT_ENV  = "production"
DEFAULT_HOST = "prod-us"

# ── Exclusion filters ────────────────────────────────────────
# Glob patterns for resource names to exclude from the dashboard.
# Supports * (any chars) and ? (single char).
# Examples: "MWD*", "TEST_*", "*_deprecated"

EXCLUDE_TEMPLATES = [
    # "MWD*",
    # "TEST_*",
]

EXCLUDE_PROJECTS = [
    # "MWD*",
]

EXCLUDE_ORGS = [
    # "MWD*",
]

# ── Cache settings ────────────────────────────────────────────
CACHE_TTL_MINUTES = 30
DB_PATH           = "aap_cache.db"

# ── Global settings ───────────────────────────────────────────
PAGE_SIZE   = 200
TIMEOUT     = 30
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 5000
