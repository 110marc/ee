/* ssl.js — SSL certificate checker, cache-backed */
'use strict';

var _data = null;

function el(id) { return document.getElementById(id); }
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Boot — load from cache only, never live on entry ──────────
async function boot() {
  showEmpty('<span class="spinner"></span> Loading...');
  try {
    var res  = await fetch('/api/ssl');
    var data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed');

    if (!data.results || !data.results.length) {
      showEmpty(
        '<div style="text-align:center;padding:40px 0">' +
        '<div style="font-size:2rem;margin-bottom:12px">&#x1F512;</div>' +
        '<div style="font-weight:600;margin-bottom:8px">No certificate data yet</div>' +
        '<div style="color:var(--muted);font-size:.85rem;margin-bottom:20px">Press <strong>Check All Hosts</strong> to run the first scan</div>' +
        '</div>'
      );
      return;
    }

    _data = data;
    render(data);
  } catch(e) {
    showEmpty('<div class="error-box">&#x2717; ' + esc(e.message) + '</div>');
  }
}

// ── Refresh — live TLS check, triggered by button only ────────
async function triggerRefresh() {
  var btn = el('refreshBtn');
  btn.disabled    = true;
  btn.textContent = '&#x21BA; Checking...';
  setCheckedAt(null, true);

  try {
    var res  = await fetch('/api/ssl?force=true');
    var data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed');
    _data = data;
    render(data);
  } catch(e) {
    showEmpty('<div class="error-box">&#x2717; ' + esc(e.message) + '</div>');
  } finally {
    btn.disabled    = false;
    btn.textContent = '&#x21BA; Check All Hosts';
  }
}

function showEmpty(msg) {
  el('emptyState').innerHTML     = msg;
  el('emptyState').style.display = 'block';
  el('sslContent').style.display = 'none';
}

// ── Last checked timestamp ────────────────────────────────────
function setCheckedAt(isoStr, loading) {
  var bar = el('checkedBar');
  if (!bar) return;
  if (loading) {
    bar.innerHTML     = '<span class="spinner" style="width:12px;height:12px;margin-right:6px"></span> Checking all hosts...';
    bar.style.display = 'flex';
    return;
  }
  if (!isoStr) { bar.style.display = 'none'; return; }

  var d          = new Date(isoStr);
  var ageSeconds = Math.round((Date.now() - d.getTime()) / 1000);
  var agoStr     = ageSeconds < 60   ? ageSeconds + 's ago'
                 : ageSeconds < 3600 ? Math.round(ageSeconds / 60) + 'm ago'
                 : Math.round(ageSeconds / 3600) + 'h ago';
  var dateStr    = d.toLocaleDateString() + ' ' + d.toLocaleTimeString();

  bar.innerHTML     = '&#x1F552; Last checked <strong>' + agoStr + '</strong> <span style="opacity:.55">(' + dateStr + ')</span>';
  bar.style.display = 'flex';
}

// ── Render ────────────────────────────────────────────────────
function render(data) {
  el('emptyState').style.display = 'none';
  el('sslContent').style.display = 'block';

  setCheckedAt(data.checked_at);

  var results = (data.results || []).slice().sort(function(a, b) {
    var order = { expired: 0, critical: 1, warning: 2, error: 3, unknown: 4, ok: 5 };
    return (order[a.status] || 99) - (order[b.status] || 99);
  });

  var s = data.summary || {};

  // ── Stat cards ────────────────────────────────────────────
  var html =
    '<div class="stats" style="margin-bottom:24px">' +
    statCard(results.length,   'Hosts Checked', 'var(--accent)') +
    statCard(s.ok       || 0,  'Valid',          'var(--success)') +
    statCard(s.warning  || 0,  'Expiring Soon',  s.warning  ? 'var(--warn)'   : 'var(--success)') +
    statCard(s.critical || 0,  'Critical',       s.critical ? 'var(--danger)' : 'var(--success)') +
    statCard(s.expired  || 0,  'Expired',        s.expired  ? 'var(--danger)' : 'var(--success)') +
    statCard(s.error    || 0,  'Unreachable',    s.error    ? 'var(--muted)'  : 'var(--success)') +
    '</div>';

  // ── Table rows ────────────────────────────────────────────
  var rows = results.map(function(r) {
    var daysCell = r.days_left !== null && r.days_left !== undefined
      ? '<span class="days-' + r.status + '">'
          + (r.days_left < 0 ? 'Expired ' + Math.abs(r.days_left) + 'd ago' : r.days_left + ' days')
          + '</span>'
      : '<span class="na">\u2014</span>';

    var cnCell = r.cn
      ? '<span class="mono-val">' + esc(r.cn) + '</span>'
      : (r.error ? '<span class="error-text">' + esc(r.error) + '</span>' : '<span class="na">\u2014</span>');

    var sansCell = r.sans && r.sans.length
      ? r.sans.slice(0, 3).map(function(s){ return '<span class="group-tag">' + esc(s) + '</span>'; }).join(' ')
        + (r.sans.length > 3 ? ' <span class="na">+' + (r.sans.length - 3) + ' more</span>' : '')
      : '<span class="na">\u2014</span>';

    var issuerCell = r.issuer_cn
      ? '<span class="mono-val">' + esc(r.issuer_cn) + '</span>'
        + (r.issuer_org ? '<br><span class="na">' + esc(r.issuer_org) + '</span>' : '')
      : '<span class="na">\u2014</span>';

    var serialCell = r.serial
      ? '<span class="mono-val serial-val" title="' + esc(r.serial) + '">' + esc(String(r.serial)) + '</span>'
      : '<span class="na">\u2014</span>';

    return '<tr class="row-' + r.status + '">'
      + '<td><span class="env-label-badge">' + esc(r.env_label) + '</span></td>'
      + '<td><strong>' + esc(r.host_label) + '</strong><br><span class="na">' + esc(r.hostname) + '</span></td>'
      + '<td>' + statusBadge(r.status) + '</td>'
      + '<td>' + daysCell + '</td>'
      + '<td>' + (r.expires ? '<span class="mono-val">' + esc(formatDate(r.expires)) + '</span>' : '<span class="na">\u2014</span>') + '</td>'
      + '<td>' + cnCell + '</td>'
      + '<td>' + sansCell + '</td>'
      + '<td>' + issuerCell + '</td>'
      + '<td>' + serialCell + '</td>'
      + '</tr>';
  }).join('') || '<tr><td colspan="9" class="state">No results.</td></tr>';

  html +=
    '<div class="section-meta">'
    + '<h2>Certificate Status</h2>'
    + '<span class="count-badge">' + results.length + ' hosts</span>'
    + '<span class="endpoint-badge">TLS handshake :443</span>'
    + '</div>'
    + '<div class="search-wrap"><input class="search" id="sslFilter" placeholder="Filter by host, env, CN or issuer..."></div>'
    + '<div class="table-wrap"><table id="sslTable">'
    + '<thead><tr><th>Env</th><th>Host</th><th>Status</th><th>Days Left</th><th>Expires</th><th>CN</th><th>SANs</th><th>Issuer</th><th>Serial</th></tr></thead>'
    + '<tbody>' + rows + '</tbody>'
    + '</table></div>';

  el('sslContent').innerHTML = html;

  var f = el('sslFilter');
  if (f) f.oninput = function() { filterTable(this.value); };
}

// ── Helpers ───────────────────────────────────────────────────
function statusBadge(status) {
  var labels = { ok: '&#x2713; Valid', warning: '&#x26A0; Expiring', critical: '&#x26A0; Critical', expired: '&#x2717; Expired', error: '&#x2717; Error', unknown: '? Unknown' };
  return '<span class="status-chip ssl-' + status + '">' + (labels[status] || status) + '</span>';
}

function formatDate(certDate) {
  try { return new Date(certDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); }
  catch(e) { return certDate; }
}

function statCard(val, label, color) {
  return '<div class="stat"><div class="stat-val" style="color:' + color + '">' + val + '</div><div class="stat-label">' + label + '</div></div>';
}

function filterTable(q) {
  q = q.toLowerCase();
  document.querySelectorAll('#sslTable tbody tr').forEach(function(row) {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

// ── CSV export ────────────────────────────────────────────────
function exportCSV() {
  if (!_data) return;
  var rows = [['Env','Host','Hostname','Status','Days Left','Expires','Issued','CN','SANs','Issuer CN','Issuer Org','Serial']];
  (_data.results || []).forEach(function(r) {
    rows.push([
      r.env_label, r.host_label, r.hostname, r.status,
      r.days_left !== undefined ? r.days_left : '',
      r.expires || '', r.issued || '',
      r.cn || '', (r.sans || []).join(' | '),
      r.issuer_cn || '', r.issuer_org || '', r.serial || '',
    ]);
  });
  var csv  = rows.map(function(r){ return r.map(function(c){ return '"'+String(c||'').replace(/"/g,'""')+'"'; }).join(','); }).join('\r\n');
  var blob = new Blob([csv], {type:'text/csv'});
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href=url; a.download='ssl-certs.csv'; a.click();
  URL.revokeObjectURL(url);
}

window.addEventListener('DOMContentLoaded', boot);
