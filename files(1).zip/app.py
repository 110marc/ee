"""
app.py — Application factory and entry point.
"""

from __future__ import annotations

import logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

from flask import Flask, send_from_directory
from routes import (
    ee_bp, projects_bp, templates_bp, orgs_bp, creds_bp,
    summary_bp, hosts_bp, cache_bp, refresh_bp, debug_bp,
)
import database as db
import config


def create_app() -> Flask:
    app = Flask(__name__, static_folder="static")
    db.init_db()
    for bp in (hosts_bp, cache_bp, refresh_bp, debug_bp, orgs_bp, creds_bp, ee_bp, projects_bp, templates_bp, summary_bp):
        app.register_blueprint(bp)

    @app.route("/")
    def landing():
        return send_from_directory("static", "index.html")

    @app.route("/ee")
    def ee_dashboard():
        return send_from_directory("static", "ee.html")

    @app.route("/credentials")
    def credentials_view():
        return send_from_directory("static", "credentials.html")

    return app


if __name__ == "__main__":
    print("\n  AAP EE Dashboard")
    print("  ─────────────────────────────────────────")
    print(f"  Cache TTL : {config.CACHE_TTL_MINUTES} minutes  |  DB: {config.DB_PATH}")
    for env_key, env in config.ENVIRONMENTS.items():
        print(f"\n  [{env['label']}]")
        for host_key, h in env["hosts"].items():
            marker = " <- default" if host_key == config.DEFAULT_HOST else ""
            print(f"    {host_key:<20} {h['label']:<18} {h['url']}{marker}")
    print(f"\n  API endpoints:")
    print(f"    GET    /api/hosts")
    print(f"    GET    /api/summary?host=<key>")
    print(f"    POST   /api/refresh?host=<key>    (background refresh)")
    print(f"    GET    /api/refresh/status?host=<key>")
    print(f"    GET    /api/cache")
    print(f"    DELETE /api/cache?host=<key>")
    print(f"\n  UI  ->  http://localhost:{config.SERVER_PORT}\n")
    app = create_app()
    app.run(host=config.SERVER_HOST, port=config.SERVER_PORT, debug=False)
