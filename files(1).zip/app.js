// ── State ─────────────────────────────────────────────────────
let _envs       = [];
let _activeEnv  = null;
let _activeHost = null;
let _data       = null;
let _activeRes  = 'ees';
let _pollTimer  = null;
let _refreshing    = false;
let _allowRefresh  = true;
let _envStats      = null;

const ENV_COLORS = ['var(--accent)','var(--accent2)','var(--accent3)','var(--accent4)'];

// ── Tiny helpers ──────────────────────────────────────────────
function enc(s)  { return encodeURIComponent(s); }
function el(id)  { return document.getElementById(id); }

function enableBtn() {
  const b = el('forceBtn');
  if (!b) return;
  if (_allowRefresh) {
    b.disabled = false;
    b.title    = '';
  } else {
    b.disabled = true;
    b.title    = 'Refresh is disabled for this environment';
  }
  b.textContent = '↺ Refresh from AAP';
}
function disableBtn() {
  const b = el('forceBtn');
  if (!b) return;
  b.disabled    = true;
  b.textContent = '↺ Refreshing...';
}

// ── Status bar ────────────────────────────────────────────────
function showStatusBar() {
  const bar = el('statusBar');
  if (bar) bar.style.display = 'flex';
}

var TTL_MINUTES = 30;  // kept in sync with server config

function setStatus(state, syncedAt, errMsg) {
  showStatusBar();
  const dot  = el('statusDot');
  const text = el('statusText');
  const ttl  = el('ttlText');
  if (!dot || !text) return;

  dot.className = 'status-dot ' + state;

  if (state === 'error') {
    text.innerHTML = '<span style="color:var(--danger)">&#x2717; ' + (errMsg || 'Unknown error') + '</span>';

  } else if (state === 'refreshing') {
    text.innerHTML = '<span class="spinner warn"></span>Fetching from AAP \u2014 UI remains usable';

  } else if (syncedAt) {
    const d          = new Date(syncedAt);
    const ageSeconds = Math.round((Date.now() - d.getTime()) / 1000);
    const ttlSeconds = TTL_MINUTES * 60;
    const remaining  = ttlSeconds - ageSeconds;
    const isStale    = ageSeconds > ttlSeconds;

    const agoStr = ageSeconds < 60 ? ageSeconds + 's ago'
                 : ageSeconds < 3600 ? Math.round(ageSeconds / 60) + 'm ago'
                 : Math.round(ageSeconds / 3600) + 'h ago';

    const dateStr = d.toLocaleDateString() + ' ' + d.toLocaleTimeString();

    const staleWarning = isStale
      ? ' <span style="color:var(--warn);margin-left:6px">&#9888; stale</span>'
      : '';

    dot.className = 'status-dot ' + (isStale ? 'error' : 'fresh');

    text.innerHTML = '<strong>' + (isStale ? 'Stale cache' : 'Cached') + '</strong>'
      + ' \u00b7 last synced ' + agoStr
      + ' <span style="opacity:.6">(' + dateStr + ')</span>'
      + staleWarning;

    if (ttl) {
      if (isStale) {
        ttl.textContent = 'TTL expired';
        ttl.style.color = 'var(--warn)';
      } else {
        const remMin = Math.ceil(remaining / 60);
        ttl.textContent = 'TTL: ' + remMin + 'min left';
        ttl.style.color = '';
      }
    }
    return;

  } else {
    text.innerHTML = 'No cached data \u2014 press <strong>\u21ba Refresh from AAP</strong>';
  }

  if (ttl) { ttl.textContent = ''; ttl.style.color = ''; }
}

// ── Boot ──────────────────────────────────────────────────────
async function boot() {
  if (window.location.protocol === 'file:') {
    el('emptyState').innerHTML = '&#x2717; Serve via Flask: <strong>python app.py</strong> then open <strong>http://localhost:5000</strong>';
    return;
  }

  try {
    let res;
    try {
      res = await fetch('/api/hosts');
    } catch (e) {
      throw new Error('Cannot reach Flask \u2014 is app.py running? ' + e.message);
    }

    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error('/api/hosts returned ' + res.status + ': ' + body.slice(0, 120));
    }

    let data;
    try {
      data = await res.json();
    } catch (e) {
      throw new Error('/api/hosts returned non-JSON \u2014 check app.py terminal for errors');
    }

    if (!data.success) throw new Error(data.error || 'Unknown error from /api/hosts');
    if (!Array.isArray(data.environments) || !data.environments.length)
      throw new Error('No environments returned \u2014 check ENVIRONMENTS in config.py');

    _envs       = data.environments;
    _activeEnv  = data.default_env  || _envs[0].key;
    _activeHost = data.default_host || _envs[0].hosts[0].key;

    const allKeys = _envs.flatMap(e => e.hosts.map(h => h.key));
    if (!allKeys.includes(_activeHost)) _activeHost = allKeys[0];

    var activeEnvObj = _envs.find(function(e) { return e.key === _activeEnv; });
    _allowRefresh = activeEnvObj ? activeEnvObj.allow_refresh !== false : true;

    buildEnvTabs();
    renderHostPills(_activeEnv);
    updateHostUrl(_activeHost);

    el('envBar').style.display    = 'block';
    showStatusBar();
    enableBtn();

    await Promise.all([loadFromCache(), loadEnvSummary()]);

  } catch (e) {
    console.error('boot() failed:', e);
    el('emptyState').innerHTML =
      '&#x2717; ' + e.message +
      '<br><small style="color:var(--muted)">Check browser console and app terminal.</small>';
    enableBtn();
  }
}

// ── Load from DB cache (no AAP call) ─────────────────────────
async function loadFromCache() {
  try {
    const res  = await fetch('/api/summary?host=' + enc(_activeHost));
    const data = await res.json();

    if (data.success && (data.ees.length || data.projects.length || data.templates.length)) {
      _data = data;
      renderAll(data);
      setStatus('fresh', data.synced_at);
    } else {
      el('emptyState').innerHTML  = 'No cached data yet \u2014 press <strong>\u21ba Refresh from AAP</strong> to fetch.';
      el('emptyState').style.display = 'block';
      setStatus('empty', null);
      enableBtn();
    }
  } catch (e) {
    console.warn('loadFromCache failed:', e);
    el('emptyState').innerHTML  = '&#x2717; Failed to load: ' + e.message;
    el('emptyState').style.display = 'block';
    setStatus('empty', null);
    enableBtn();
  }
}

// ── Refresh (user action only) ────────────────────────────────
// ── Env-level aggregated summary ─────────────────────────────
async function loadEnvSummary() {
  try {
    var res  = await fetch('/api/summary/env?env=' + enc(_activeEnv));
    var data = await res.json();
    if (data.success) {
      _envStats = data;
      renderEnvStats(data);
    }
  } catch (e) {
    console.warn('loadEnvSummary failed:', e);
  }
}

function renderEnvStats(data) {
  var bar = el('envStatsBar');
  if (!bar) return;
  if (!data || !data.success) { bar.style.display = 'none'; return; }
  // Show bar even if all counts are zero — user needs to know env exists
  var t = data.totals || {
    total_ees: 0, total_orgs: 0, orgs_with_ee: 0,
    total_projects: 0, projects_with_ee: 0,
    total_templates: 0, templates_with_ee: 0
  };

  var hosts = data.hosts || [];
  var onlineCount = hosts.filter(function(h) { return h.has_data; }).length;

  bar.innerHTML =
    '<span class="env-stats-label">' + data.env_label + ' totals</span>' +
    envStatChip(t.total_ees,         'EEs') +
    envStatChip(t.orgs_with_ee,      'Orgs w/ EE',      t.total_orgs) +
    envStatChip(t.projects_with_ee,  'Projects w/ EE',  t.total_projects) +
    envStatChip(t.templates_with_ee, 'Templates w/ EE', t.total_templates) +
    '<span class="env-stats-hosts">' + onlineCount + ' of ' + hosts.length + ' hosts cached</span>';
  bar.style.display = 'flex';
}

function envStatChip(val, label, total) {
  var sub = total != null ? '<span class="env-chip-sub"> of ' + total + '</span>' : '';
  return '<span class="env-stat-chip"><strong>' + val + '</strong> ' + label + sub + '</span>';
}

async function triggerRefresh() {
  if (!_allowRefresh) return;
  clearInterval(_pollTimer);
  _refreshing = false;
  disableBtn();
  setStatus('refreshing', null);

  try {
    const res = await fetch('/api/refresh?host=' + enc(_activeHost) + '&force=true', { method: 'POST' });
    if (!res.ok) throw new Error('Server ' + res.status);
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to start refresh');

    _refreshing = true;
    _pollTimer  = setInterval(pollRefresh, 3000);

  } catch (e) {
    console.error('triggerRefresh failed:', e);
    setStatus('error', null, e.message);
    enableBtn();
  }
}

async function pollRefresh() {
  try {
    const res    = await fetch('/api/refresh/status?host=' + enc(_activeHost));
    const status = await res.json();

    if (status.status === 'done') {
      clearInterval(_pollTimer);
      _refreshing = false;
      await Promise.all([loadFromCache(), loadEnvSummary()]);
      enableBtn();

    } else if (status.status === 'error') {
      clearInterval(_pollTimer);
      _refreshing = false;
      setStatus('error', null, status.error);
      enableBtn();
    }
    // still 'refreshing' — keep polling

  } catch (e) {
    clearInterval(_pollTimer);
    _refreshing = false;
    console.error('pollRefresh failed:', e);
    setStatus('error', null, e.message);
    enableBtn();
  }
}

// ── Env / host selection ──────────────────────────────────────
function buildEnvTabs() {
  const container = el('envTabs');
  container.innerHTML = '';
  _envs.forEach(function(env, i) {
    const color = ENV_COLORS[i % ENV_COLORS.length];
    const b = document.createElement('button');
    b.className = 'env-tab' + (env.key === _activeEnv ? ' active' : '');
    b.id        = 'env-tab-' + env.key;
    b.innerHTML = '<span class="env-dot" style="background:' + color + '"></span>' + env.label;
    b.onclick   = function() { selectEnv(env.key); };
    container.appendChild(b);
  });
}

function selectEnv(envKey) {
  if (_activeEnv === envKey) return;
  _activeEnv  = envKey;
  _activeHost = _envs.find(function(e) { return e.key === envKey; }).hosts[0].key;
  var env = _envs.find(function(e) { return e.key === envKey; });
  _allowRefresh = env ? env.allow_refresh !== false : true;
  _envStats = null;
  var envStatBar = el('envStatsBar');
  if (envStatBar) envStatBar.style.display = 'none';
  loadEnvSummary();
  document.querySelectorAll('.env-tab').forEach(function(t) {
    t.classList.toggle('active', t.id === 'env-tab-' + envKey);
  });
  renderHostPills(envKey);
  updateHostUrl(_activeHost);
  clearAndReload();
}

function renderHostPills(envKey) {
  const pills = el('hostPills');
  pills.innerHTML = '';
  _envs.find(function(e) { return e.key === envKey; }).hosts.forEach(function(h) {
    const b = document.createElement('button');
    b.className   = 'host-pill' + (h.key === _activeHost ? ' active' : '');
    b.id          = 'host-pill-' + h.key;
    b.textContent = h.label;
    b.onclick     = function() { selectHost(h.key); };
    pills.appendChild(b);
  });
}

function selectHost(hostKey) {
  if (_activeHost === hostKey) return;
  _activeHost = hostKey;
  document.querySelectorAll('.host-pill').forEach(function(p) {
    p.classList.toggle('active', p.id === 'host-pill-' + hostKey);
  });
  updateHostUrl(hostKey);
  clearAndReload();
}

function updateHostUrl(hostKey) {
  const env  = _envs.find(function(e) { return e.hosts.some(function(h) { return h.key === hostKey; }); });
  const host = env && env.hosts.find(function(h) { return h.key === hostKey; });
  el('hostUrl').textContent = host ? host.url : '';
}

async function clearAndReload() {
  clearInterval(_pollTimer);
  _refreshing = false;
  _data       = null;

  ['statsRow','resTabs'].forEach(function(id) { el(id).style.display = 'none'; });
  el('exportBtn').style.display = 'none';
  el('errorBox').style.display  = 'none';
  ['ees','orgs','projects','templates','credentials'].forEach(function(t) { el('panel-' + t).innerHTML = ''; });
  el('emptyState').innerHTML     = '';
  el('emptyState').style.display = 'block';

  setStatus('empty', null);
  enableBtn();

  await loadFromCache();
}

// ── Render ────────────────────────────────────────────────────
function renderAll(data) {
  const s  = data.stats;
  const sr = el('statsRow');
  sr.innerHTML =
    statCard(s.total_ees,         'Execution Envs',  null) +
    statCard(s.total_credentials, 'Credentials',     null) +
    statCard(s.orgs_with_ee,      'Orgs w/ EE',      s.total_orgs) +
    statCard(s.projects_with_ee,  'Projects w/ EE',  s.total_projects) +
    statCard(s.templates_with_ee, 'Templates w/ EE', s.total_templates);
  sr.style.display = 'grid';

  el('panel-ees').innerHTML       = renderEEs(data.ees);
  el('panel-orgs').innerHTML      = renderOrgs(data.orgs, s.total_orgs);
  el('panel-credentials').innerHTML = renderCredentials(data.credentials || [], s);
  el('panel-projects').innerHTML  = renderProjects(data.projects, s.total_projects);
  el('panel-templates').innerHTML = renderTemplates(data.templates, s.total_templates);

  el('emptyState').style.display = 'none';
  el('resTabs').style.display    = 'flex';
  el('exportBtn').style.display  = 'inline-block';
  enableBtn();
  switchResTab(_activeRes);
}

function switchResTab(name) {
  _activeRes = name;
  ['ees','orgs','projects','templates','credentials'].forEach(function(t) {
    el('panel-' + t).classList.toggle('active', t === name);
    el('tab-'   + t).classList.toggle('active', t === name);
  });
}

function statCard(val, label, total) {
  const sub = total != null ? '<div class="stat-sub">of ' + total + ' total</div>' : '';
  return '<div class="stat"><div class="stat-val">' + val + '</div><div class="stat-label">' + label + '</div>' + sub + '</div>';
}

function renderEEs(ees) {
  const rows = ees.map(function(e) {
    return '<tr>'
      + '<td><span class="id-chip">#' + e.id + '</span></td>'
      + '<td><strong>' + e.name + '</strong></td>'
      + '<td><span class="image-text">' + e.image + '</span>' + (e.pull ? '<span class="pull-badge">' + e.pull + '</span>' : '') + '</td>'
      + '<td><span class="org-badge">' + e.org + '</span></td>'
      + '</tr>';
  }).join('');
  return section('Execution Environments', ees.length, null,
    '/api/execution_environments?host=' + _activeHost,
    '<table id="tbl-ees"><thead><tr><th>ID</th><th>Name</th><th>Image</th><th>Scope</th></tr></thead><tbody>' + rows + '</tbody></table>',
    'tbl-ees', 'Filter by name or image...');
}

function renderOrgs(orgs, total) {
  if (!orgs || !orgs.length) return emptySection('No organizations have an EE assigned.', '/api/organizations?host=' + _activeHost);
  var rows = orgs.map(function(o) {
    return '<tr>'
      + '<td><span class="id-chip">#' + o.id + '</span></td>'
      + '<td><strong>' + o.name + '</strong></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + o.ee_name + '</span></td>'
      + '<td><span class="id-chip">#' + o.ee_id + '</span></td>'
      + '</tr>';
  }).join('');
  return section('Organizations', orgs.length, total,
    '/api/organizations?host=' + _activeHost,
    '<table id="tbl-orgs"><thead><tr><th>ID</th><th>Organization</th><th>Execution Environment</th><th>EE ID</th></tr></thead><tbody>' + rows + '</tbody></table>',
    'tbl-orgs', 'Filter by org or EE name...');
}

function renderProjects(projects, total) {
  if (!projects.length) return emptySection('No projects have an EE assigned.', '/api/projects?host=' + _activeHost);
  const rows = projects.map(function(p) {
    return '<tr>'
      + '<td><span class="id-chip">#' + p.id + '</span></td>'
      + '<td><strong>' + p.name + '</strong></td>'
      + '<td><span class="org-badge">' + (p.org_name || '—') + '</span></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + p.ee_name + '</span></td>'
      + '<td><span class="id-chip">#' + p.ee_id + '</span></td>'
      + '</tr>';
  }).join('');
  return section('Projects', projects.length, total,
    '/api/projects?host=' + _activeHost,
    '<table id="tbl-projects"><thead><tr><th>ID</th><th>Project</th><th>Organization</th><th>Execution Environment</th><th>EE ID</th></tr></thead><tbody>' + rows + '</tbody></table>',
    'tbl-projects', 'Filter by project, org or EE name...');
}

function renderTemplates(templates, total) {
  if (!templates.length) return emptySection('No job templates have an EE assigned.', '/api/job_templates?host=' + _activeHost);
  const rows = templates.map(function(t) {
    return '<tr>'
      + '<td><span class="id-chip">#' + t.id + '</span></td>'
      + '<td><strong>' + t.name + '</strong></td>'
      + '<td><span class="org-badge">' + (t.org_name || '—') + '</span></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + t.ee_name + '</span></td>'
      + '<td><span class="id-chip">#' + t.ee_id + '</span></td>'
      + '</tr>';
  }).join('');
  return section('Job Templates', templates.length, total,
    '/api/job_templates?host=' + _activeHost,
    '<table id="tbl-templates"><thead><tr><th>ID</th><th>Template</th><th>Organization</th><th>Execution Environment</th><th>EE ID</th></tr></thead><tbody>' + rows + '</tbody></table>',
    'tbl-templates', 'Filter by template, org or EE name...');
}

function section(title, count, total, endpoint, tableHtml, tableId, placeholder) {
  const badge = total != null ? (count + ' of ' + total + ' have EE') : (count + ' total');
  return '<div class="section-meta">'
    + '<h2>' + title + '</h2>'
    + '<span class="count-badge">' + badge + '</span>'
    + '<span class="endpoint-badge">GET ' + endpoint + '</span>'
    + '</div>'
    + '<div class="search-wrap"><input class="search" placeholder="' + placeholder + '" oninput="filterTable(this,\'' + tableId + '\')"/></div>'
    + '<div class="table-wrap">' + tableHtml + '</div>';
}

function emptySection(msg, endpoint) {
  return '<div class="section-meta"><span class="endpoint-badge">' + endpoint + '</span></div>'
    + '<div class="state">' + msg + '</div>';
}

function filterTable(input, tableId) {
  const q = input.value.toLowerCase();
  document.querySelectorAll('#' + tableId + ' tbody tr').forEach(function(row) {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

function renderCredentials(creds, stats) {
  if (!creds.length) return emptySection('No credentials cached yet.', '/api/credentials?host=' + _activeHost);

  var org_creds    = creds.filter(function(c) { return c.has_org; });
  var global_creds = creds.filter(function(c) { return !c.has_org; });

  function credRows(list, tableId) {
    return list.map(function(c) {
      var username = c.username ? '<span class="id-chip">' + c.username + '</span>' : '<span style="opacity:.35">—</span>';
      var usage    = c.usage_count > 0
        ? '<span class="ee-tag"><span class="dot"></span>' + c.usage_count + ' use' + (c.usage_count !== 1 ? 's' : '') + '</span>'
        : '<span style="opacity:.35">—</span>';
      var org      = c.org_name ? '<span class="org-badge">' + c.org_name + '</span>' : '<span style="opacity:.35">global</span>';
      return '<tr>'
        + '<td><span class="id-chip">#' + c.id + '</span></td>'
        + '<td><strong>' + c.name + '</strong>'
        + (c.description ? '<br><span style="font-size:.68rem;color:var(--muted)">' + c.description + '</span>' : '')
        + '</td>'
        + '<td>' + org + '</td>'
        + '<td><span class="pull-badge">' + (c.ctype_name || '—') + '</span></td>'
        + '<td>' + username + '</td>'
        + '<td>' + usage + '</td>'
        + '</tr>';
    }).join('');
  }

  var html = '';

  if (org_creds.length) {
    html += '<div class="section-meta" style="margin-top:0">'
      + '<h2>Organization Credentials</h2>'
      + '<span class="count-badge">' + org_creds.length + ' total</span>'
      + '<span class="endpoint-badge">GET /api/v2/credentials/</span>'
      + '</div>'
      + '<div class="search-wrap"><input class="search" placeholder="Filter by name, org or type..." oninput="filterTable(this,'tbl-creds-org')"/></div>'
      + '<div class="table-wrap"><table id="tbl-creds-org">'
      + '<thead><tr><th>ID</th><th>Name</th><th>Organization</th><th>Type</th><th>Username</th><th>Usage</th></tr></thead>'
      + '<tbody>' + credRows(org_creds, 'tbl-creds-org') + '</tbody></table></div>';
  }

  if (global_creds.length) {
    html += '<div class="section-meta" style="margin-top:24px">'
      + '<h2>Global Credentials</h2>'
      + '<span class="count-badge">' + global_creds.length + ' total</span>'
      + '</div>'
      + '<div class="search-wrap"><input class="search" placeholder="Filter by name or type..." oninput="filterTable(this,'tbl-creds-global')"/></div>'
      + '<div class="table-wrap"><table id="tbl-creds-global">'
      + '<thead><tr><th>ID</th><th>Name</th><th>Organization</th><th>Type</th><th>Username</th><th>Usage</th></tr></thead>'
      + '<tbody>' + credRows(global_creds, 'tbl-creds-global') + '</tbody></table></div>';
  }

  return html;
}

function exportCSV() {
  if (!_data) return;
  const env  = _envs.find(function(e) { return e.hosts.some(function(h) { return h.key === _activeHost; }); });
  const host = env && env.hosts.find(function(h) { return h.key === _activeHost; });
  const lines = [
    'AAP EE Report \u2014 ' + (env && env.label) + ' / ' + (host && host.label) + '  (synced: ' + _data.synced_at + ')',
    'Section,ID,Name,EE Name,Extra',
  ];
  _data.ees.forEach(function(e)      { lines.push('Execution Environment,' + e.id + ',"' + e.name + '","' + e.image + '","' + e.org + '"'); });
  _data.projects.forEach(function(p) { lines.push('Project,' + p.id + ',"' + p.name + '","' + p.ee_name + '","EE ID: ' + p.ee_id + '"'); });
  _data.templates.forEach(function(t){ lines.push('Job Template,' + t.id + ',"' + t.name + '","' + t.ee_name + '","EE ID: ' + t.ee_id + '"'); });
  const a    = document.createElement('a');
  a.href     = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv' }));
  a.download = 'aap_ee_' + (env && env.key) + '_' + _activeHost + '.csv';
  a.click();
}

boot();
