/* credentials.js — Credentials (requires common.js) */
'use strict';

var _data       = null;
var _watchUsers = [];
var _envStats   = null;

window._postBoot = function() {
  _activeHost = '__all__';
  buildHostPillsWithAll(_activeEnv);
};

window._onHostReady = async function() {
  el('credPanel').innerHTML    = '';
  el('statsRow').style.display = 'none';
  el('emptyState').innerHTML   = '<span class="spinner"></span>';
  el('emptyState').style.display = 'block';
  renderSyncedBar(null);

  if (!_watchUsers.length) {
    try {
      var cr = await fetch('/api/config');
      var cd = await cr.json();
      _watchUsers = (cd.credential_watch_users || []).map(function(u){ return u.toLowerCase(); });
    } catch(e) {}
  }

  await Promise.all([_load(), _loadEnvSummary()]);
};

window._onEnvChange = function() {
  _envStats = null;
  var bar = el('envStatsBar'); if (bar) bar.style.display = 'none';
  _activeHost = '__all__';
  buildHostPillsWithAll(_activeEnv);
};

// ── Load — single host or all hosts merged ────────────────────
async function _load() {
  try {
    var hosts = _getTargetHosts();
    var results = await Promise.all(hosts.map(function(hk){
      return fetch('/api/summary?host=' + enc(hk)).then(function(r){ return r.json(); });
    }));

    var allCreds = [];
    var latestSync = null;

    results.forEach(function(d){
      if (d.success && d.credentials && d.credentials.length) {
        allCreds = allCreds.concat(d.credentials);
        if (!latestSync || d.synced_at > latestSync) latestSync = d.synced_at;
      }
    });

    // Deduplicate by id
    var seen = {}, creds = [];
    allCreds.forEach(function(c){ if (!seen[c.id]) { seen[c.id]=true; creds.push(c); } });

    if (!creds.length) {
      el('emptyState').innerHTML   = 'No cached data \u2014 press <strong>\u21ba Refresh from AAP</strong>';
      el('emptyState').style.display = 'block';
      el('statsRow').style.display = 'none';
      renderSyncedBar(null);
      _enableBtn();
      return;
    }

    _data = { credentials: creds, synced_at: latestSync };
    _render(creds);
    renderSyncedBar(latestSync);

  } catch(e) {
    el('emptyState').innerHTML   = '&#x2717; ' + esc(e.message);
    el('emptyState').style.display = 'block';
    renderSyncedBar(null);
    _enableBtn();
  }
}

function _getTargetHosts() {
  if (_activeHost === '__all__') {
    var env = _envs.find(function(e){ return e.key === _activeEnv; });
    return env ? env.hosts.map(function(h){ return h.key; }) : [];
  }
  return [_activeHost];
}

// ── Render ────────────────────────────────────────────────────
function _render(creds) {
  // ── Stat cards ────────────────────────────────────────────
  var sr = el('statsRow');
  var statsHtml = '<div class="stat"><div class="stat-val">' + creds.length + '</div><div class="stat-label">Total Credentials</div></div>';
  _watchUsers.forEach(function(watch) {
    var count = creds.filter(function(c){
      return c.username && c.username.toLowerCase().includes(watch);
    }).length;
    statsHtml += '<div class="stat"><div class="stat-val">' + count + '</div><div class="stat-label">Username: ' + esc(watch) + '</div></div>';
  });
  sr.innerHTML = statsHtml;
  sr.style.display = 'grid';

  el('emptyState').style.display = 'none';
  el('credPanel').innerHTML = _renderTable(creds);
}

function _renderTable(creds) {
  // Build unique org list for filter bar
  var orgSeen = {}, orgs = [];
  creds.forEach(function(c){
    var o = c.org_name || '';
    if (o && !orgSeen[o]) { orgSeen[o]=true; orgs.push(o); }
  });
  orgs.sort();

  var orgBar = orgs.length > 1
    ? '<div class="org-filter-bar" id="orgbar-creds">'
      + '<button class="org-pill active" onclick="_credFilter(null)">All</button>'
      + orgs.map(function(o){
          return '<button class="org-pill" onclick="_credFilter(\'' + esc(o) + '\')">' + esc(o) + '</button>';
        }).join('')
      + '</div>'
    : '';

  var rows = creds.map(function(c) {
    var org      = c.org_name ? '<span class="org-badge">'  + esc(c.org_name) + '</span>' : '<span class="na">global</span>';
    var username = c.username ? '<span class="id-chip">'    + esc(c.username) + '</span>' : '<span class="na">\u2014</span>';
    var created  = c.created  ? '<span class="mono-val">'   + fmtDate(c.created)  + '</span>' : '<span class="na">\u2014</span>';
    var modified = c.modified ? '<span class="mono-val">'   + fmtDate(c.modified) + '</span>' : '<span class="na">\u2014</span>';
    return '<tr data-org="' + esc(c.org_name||'') + '">'
      + '<td><span class="id-chip">#' + c.id + '</span></td>'
      + '<td><strong>' + esc(c.name) + '</strong>'
      + (c.description ? '<br><span class="row-sub">' + esc(c.description) + '</span>' : '')
      + '</td>'
      + '<td>' + org + '</td>'
      + '<td><span class="type-badge">' + esc(c.ctype_name || '\u2014') + '</span></td>'
      + '<td>' + username + '</td>'
      + '<td>' + created  + '</td>'
      + '<td>' + modified + '</td>'
      + '</tr>';
  }).join('');

  return '<div class="section-meta"><h2>Credentials</h2><span class="count-badge">' + creds.length + ' total</span></div>'
    + orgBar
    + '<div class="search-wrap"><input class="search" id="srch-creds" placeholder="Filter by name, org or type\u2026" oninput="_credSearch()"/></div>'
    + '<div class="table-wrap"><table id="tbl-creds">'
    + '<thead><tr><th>ID</th><th>Name</th><th>Organization</th><th>Type</th><th>Username</th><th>Created</th><th>Modified</th></tr></thead>'
    + '<tbody>' + rows + '</tbody></table></div>';
}

// ── Filter helpers ────────────────────────────────────────────
var _credActiveOrg = null;

function _credFilter(org) {
  _credActiveOrg = org;
  document.querySelectorAll('#orgbar-creds .org-pill').forEach(function(b){
    b.classList.toggle('active', org === null ? b.textContent === 'All' : b.textContent === org);
  });
  _applyCredFilters();
}

function _credSearch() { _applyCredFilters(); }

function _applyCredFilters() {
  var q = el('srch-creds') ? el('srch-creds').value.toLowerCase() : '';
  document.querySelectorAll('#tbl-creds tbody tr').forEach(function(row){
    var orgOk  = _credActiveOrg === null || row.dataset.org === _credActiveOrg;
    var textOk = !q || row.textContent.toLowerCase().includes(q);
    row.style.display = (orgOk && textOk) ? '' : 'none';
  });
}

// ── Env summary bar ───────────────────────────────────────────
async function _loadEnvSummary() {
  await loadEnvSummary(function(data) {
    _envStats = data;
    var bar = el('envStatsBar'); if (!bar) return;
    var t = data.totals || {}, hosts = data.hosts || [];
    var online = hosts.filter(function(h){ return h.has_data; }).length;
    bar.innerHTML =
      '<span class="env-stats-label">' + esc(data.env_label) + ' totals</span>' +
      envStatChip(t.total_credentials  || 0, 'Credentials') +
      envStatChip(t.org_credentials    || 0, 'Org',    t.total_credentials) +
      envStatChip(t.global_credentials || 0, 'Global', t.total_credentials) +
      '<span class="env-stats-hosts">' + online + ' / ' + hosts.length + ' hosts cached</span>';
    bar.style.display = 'flex';
  });
}

function triggerRefresh() {
  if (_activeHost === '__all__') {
    var env = _envs.find(function(e){ return e.key === _activeEnv; });
    if (env) env.hosts.forEach(function(h){ startRefresh('credentials', h.key); });
  } else {
    startRefresh('credentials');
  }
}

window.addEventListener('DOMContentLoaded', commonBoot);
