// ── State ─────────────────────────────────────────────────────
let _envs         = [];
let _activeEnv    = null;
let _activeHost   = null;
let _data         = null;
let _pollTimer    = null;
let _allowRefresh = true;
let _envStats     = null;

const ENV_COLORS = ['var(--accent)','var(--accent2)','var(--accent3)','var(--accent4)'];

// ── Tiny helpers ──────────────────────────────────────────────
function enc(s) { return encodeURIComponent(s); }
function el(id)  { return document.getElementById(id); }

function enableBtn() {
  const b = el('forceBtn');
  if (!b) return;
  if (_allowRefresh) {
    b.disabled = false;
    b.title    = '';
  } else {
    b.disabled = true;
    b.title    = 'Refresh is disabled for this environment';
  }
  b.textContent = '↺ Refresh from AAP';
}
function disableBtn() {
  const b = el('forceBtn');
  if (!b) return;
  b.disabled    = true;
  b.textContent = '↺ Refreshing...';
}

// ── Status bar ────────────────────────────────────────────────
function showStatusBar() {
  const bar = el('statusBar');
  if (bar) bar.style.display = 'flex';
}

var TTL_MINUTES = 30;

function setStatus(state, syncedAt, errMsg) {
  showStatusBar();
  const dot  = el('statusDot');
  const text = el('statusText');
  const ttl  = el('ttlText');
  if (!dot || !text) return;

  dot.className = 'status-dot ' + state;

  if (state === 'error') {
    text.innerHTML = '<span style="color:var(--danger)">&#x2717; ' + (errMsg || 'Unknown error') + '</span>';

  } else if (state === 'refreshing') {
    text.innerHTML = '<span class="spinner warn"></span>Fetching from AAP — UI remains usable';

  } else if (syncedAt) {
    const d          = new Date(syncedAt);
    const ageSeconds = Math.round((Date.now() - d.getTime()) / 1000);
    const ttlSeconds = TTL_MINUTES * 60;
    const remaining  = ttlSeconds - ageSeconds;
    const isStale    = ageSeconds > ttlSeconds;

    const agoStr = ageSeconds < 60 ? ageSeconds + 's ago'
                 : ageSeconds < 3600 ? Math.round(ageSeconds / 60) + 'm ago'
                 : Math.round(ageSeconds / 3600) + 'h ago';

    const dateStr = d.toLocaleDateString() + ' ' + d.toLocaleTimeString();
    const staleWarning = isStale
      ? ' <span style="color:var(--warn);margin-left:6px">&#9888; stale</span>'
      : '';

    dot.className = 'status-dot ' + (isStale ? 'error' : 'fresh');
    text.innerHTML = '<strong>' + (isStale ? 'Stale cache' : 'Cached') + '</strong>'
      + ' · last synced ' + agoStr
      + ' <span style="opacity:.6">(' + dateStr + ')</span>'
      + staleWarning;

    if (ttl) {
      if (isStale) {
        ttl.textContent = 'TTL expired';
        ttl.style.color = 'var(--warn)';
      } else {
        ttl.textContent = 'TTL: ' + Math.ceil(remaining / 60) + 'min left';
        ttl.style.color = '';
      }
    }
    return;

  } else {
    text.innerHTML = 'No cached data — press <strong>↺ Refresh from AAP</strong>';
  }
  if (ttl) { ttl.textContent = ''; ttl.style.color = ''; }
}

// ── Boot ──────────────────────────────────────────────────────
async function boot() {
  if (window.location.protocol === 'file:') {
    el('emptyState').innerHTML = '&#x2717; Serve via Flask: <strong>python app.py</strong>';
    return;
  }

  try {
    let res;
    try {
      res = await fetch('/api/hosts');
    } catch (e) {
      throw new Error('Cannot reach Flask — is app.py running? ' + e.message);
    }

    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Unknown error from /api/hosts');
    if (!Array.isArray(data.environments) || !data.environments.length)
      throw new Error('No environments in config.py');

    _envs       = data.environments;
    _activeEnv  = data.default_env  || _envs[0].key;
    _activeHost = data.default_host || _envs[0].hosts[0].key;

    const allKeys = _envs.flatMap(e => e.hosts.map(h => h.key));
    if (!allKeys.includes(_activeHost)) _activeHost = allKeys[0];

    var activeEnvObj = _envs.find(function(e) { return e.key === _activeEnv; });
    _allowRefresh = activeEnvObj ? activeEnvObj.allow_refresh !== false : true;

    buildEnvTabs();
    renderHostPills(_activeEnv);
    updateHostUrl(_activeHost);

    el('envBar').style.display = 'block';
    showStatusBar();
    enableBtn();

    await Promise.all([loadFromCache(), loadEnvSummary()]);

  } catch (e) {
    console.error('boot() failed:', e);
    el('emptyState').innerHTML = '&#x2717; ' + e.message +
      '<br><small style="color:var(--muted)">Check browser console and app terminal.</small>';
    enableBtn();
  }
}

// ── Load credentials from cache ───────────────────────────────
async function loadFromCache() {
  try {
    const res  = await fetch('/api/summary?host=' + enc(_activeHost));
    const data = await res.json();

    if (data.success && data.credentials && data.credentials.length) {
      _data = data;
      renderAll(data);
      el('emptyState').style.display = 'none';
      setStatus('fresh', data.synced_at);
    } else {
      el('emptyState').innerHTML   = 'No cached data yet — press <strong>↺ Refresh from AAP</strong> to fetch.';
      el('emptyState').style.display = 'block';
      setStatus('empty', null);
      enableBtn();
    }
  } catch (e) {
    el('emptyState').innerHTML   = '&#x2717; Failed to load: ' + e.message;
    el('emptyState').style.display = 'block';
    setStatus('empty', null);
    enableBtn();
  }
}

// ── Render ────────────────────────────────────────────────────
function renderAll(data) {
  const s    = data.stats || {};
  const creds = data.credentials || [];

  // Stat cards
  const statsRow = el('statsRow');
  if (statsRow) {
    statsRow.style.display = 'grid';
    statsRow.innerHTML =
      statCard(s.total_credentials || 0, 'Total Credentials', null) +
      statCard(s.org_credentials   || 0, 'Org Credentials',   null) +
      statCard(s.global_credentials|| 0, 'Global Credentials',null);
  }

  el('credPanel').innerHTML = renderCredentials(creds);
}

function statCard(val, label, sub) {
  return '<div class="stat"><div class="stat-val">' + val + '</div>'
    + '<div class="stat-label">' + label + '</div>'
    + (sub ? '<div class="stat-sub">of ' + sub + '</div>' : '')
    + '</div>';
}

function renderCredentials(creds) {
  if (!creds.length) {
    return '<div class="state">No credentials cached yet — press <strong>↺ Refresh from AAP</strong> to fetch.</div>';
  }

  var org_creds    = creds.filter(function(c) { return c.has_org; });
  var global_creds = creds.filter(function(c) { return !c.has_org; });

  function credRows(list) {
    return list.map(function(c) {
      var username = c.username
        ? '<span class="id-chip">' + c.username + '</span>'
        : '<span style="opacity:.35">—</span>';
      var usage = c.usage_count > 0
        ? '<span class="ee-tag"><span class="dot"></span>' + c.usage_count + ' use' + (c.usage_count !== 1 ? 's' : '') + '</span>'
        : '<span style="opacity:.35">—</span>';
      var org = c.org_name
        ? '<span class="org-badge">' + c.org_name + '</span>'
        : '<span style="opacity:.35">global</span>';
      return '<tr>'
        + '<td><span class="id-chip">#' + c.id + '</span></td>'
        + '<td><strong>' + c.name + '</strong>'
        + (c.description ? '<br><span style="font-size:.68rem;color:var(--muted)">' + c.description + '</span>' : '')
        + '</td>'
        + '<td>' + org + '</td>'
        + '<td><span class="pull-badge">' + (c.ctype_name || '—') + '</span></td>'
        + '<td>' + username + '</td>'
        + '<td>' + usage + '</td>'
        + '</tr>';
    }).join('');
  }

  var html = '';

  if (org_creds.length) {
    html += '<div class="section-meta" style="margin-top:0">'
      + '<h2>Organization Credentials</h2>'
      + '<span class="count-badge">' + org_creds.length + ' total</span>'
      + '<span class="endpoint-badge">GET /api/credentials</span>'
      + '</div>'
      + '<div class="search-wrap"><input class="search" placeholder="Filter by name, org or type..." oninput="filterTable(this,\'tbl-creds-org\')"/></div>'
      + '<div class="table-wrap"><table id="tbl-creds-org">'
      + '<thead><tr><th>ID</th><th>Name</th><th>Organization</th><th>Type</th><th>Username</th><th>Usage</th></tr></thead>'
      + '<tbody>' + credRows(org_creds) + '</tbody></table></div>';
  }

  if (global_creds.length) {
    html += '<div class="section-meta" style="margin-top:24px">'
      + '<h2>Global Credentials</h2>'
      + '<span class="count-badge">' + global_creds.length + ' total</span>'
      + '</div>'
      + '<div class="search-wrap"><input class="search" placeholder="Filter by name or type..." oninput="filterTable(this,\'tbl-creds-global\')"/></div>'
      + '<div class="table-wrap"><table id="tbl-creds-global">'
      + '<thead><tr><th>ID</th><th>Name</th><th>Organization</th><th>Type</th><th>Username</th><th>Usage</th></tr></thead>'
      + '<tbody>' + credRows(global_creds) + '</tbody></table></div>';
  }

  return html;
}

// ── Search / filter ───────────────────────────────────────────
function filterTable(input, tableId) {
  const q    = input.value.toLowerCase();
  const rows = document.querySelectorAll('#' + tableId + ' tbody tr');
  rows.forEach(function(row) {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

// ── Env summary bar ───────────────────────────────────────────
async function loadEnvSummary() {
  try {
    const res  = await fetch('/api/summary/env?env=' + enc(_activeEnv));
    const data = await res.json();
    if (data.success) {
      _envStats = data;
      renderEnvStats(data);
    }
  } catch (e) {
    console.warn('loadEnvSummary failed:', e);
  }
}

function renderEnvStats(data) {
  const bar = el('envStatsBar');
  if (!bar) return;
  if (!data || !data.success) { bar.style.display = 'none'; return; }

  const t     = data.totals || {};
  const hosts = data.hosts  || [];
  const onlineCount = hosts.filter(function(h) { return h.has_data; }).length;

  bar.innerHTML =
    '<span class="env-stats-label">' + data.env_label + ' totals</span>' +
    envStatChip(t.total_credentials  || 0, 'Credentials') +
    envStatChip(t.org_credentials    || 0, 'Org Credentials',    t.total_credentials) +
    envStatChip(t.global_credentials || 0, 'Global Credentials', t.total_credentials) +
    '<span class="env-stats-hosts">' + onlineCount + ' of ' + hosts.length + ' hosts cached</span>';
  bar.style.display = 'flex';
}

function envStatChip(val, label, total) {
  const sub = total != null ? '<span class="env-chip-sub"> of ' + total + '</span>' : '';
  return '<span class="env-stat-chip"><strong>' + val + '</strong> ' + label + sub + '</span>';
}

// ── Background refresh polling ────────────────────────────────
async function triggerRefresh() {
  if (!_allowRefresh) return;
  disableBtn();
  setStatus('refreshing', null);

  try {
    const res  = await fetch('/api/refresh?host=' + enc(_activeHost) + '&scope=credentials', { method: 'POST' });
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to start refresh');
    _pollTimer = setInterval(pollRefresh, 3000);
  } catch (e) {
    setStatus('error', null, e.message);
    enableBtn();
  }
}

async function pollRefresh() {
  try {
    const res  = await fetch('/api/refresh/status?host=' + enc(_activeHost) + '&scope=credentials');
    const status = await res.json();

    if (status.status === 'idle' || status.status === 'done') {
      clearInterval(_pollTimer);
      _pollTimer = null;
      await Promise.all([loadFromCache(), loadEnvSummary()]);
      enableBtn();

    } else if (status.status === 'error') {
      clearInterval(_pollTimer);
      _pollTimer = null;
      setStatus('error', null, status.error || 'Refresh failed');
      enableBtn();
    }
  } catch (e) {
    clearInterval(_pollTimer);
    _pollTimer = null;
    setStatus('error', null, e.message);
    enableBtn();
  }
}

// ── Env / host selectors ──────────────────────────────────────
function buildEnvTabs() {
  const container = el('envTabs');
  if (!container) return;
  container.innerHTML = _envs.map(function(env, i) {
    const active = env.key === _activeEnv ? ' active' : '';
    const color  = ENV_COLORS[i % ENV_COLORS.length];
    return '<button class="env-tab' + active + '" onclick="selectEnv(\'' + env.key + '\')" style="--env-color:' + color + '">' + env.label + '</button>';
  }).join('');
}

function renderHostPills(envKey) {
  const container = el('hostPills');
  if (!container) return;
  const env = _envs.find(function(e) { return e.key === envKey; });
  if (!env) return;
  container.innerHTML = env.hosts.map(function(h) {
    const active = h.key === _activeHost ? ' active' : '';
    return '<button class="pill' + active + '" onclick="selectHost(\'' + h.key + '\')">' + h.label + '</button>';
  }).join('');
}

function updateHostUrl(hostKey) {
  const urlEl = el('hostUrl');
  if (!urlEl) return;
  for (const env of _envs) {
    const host = env.hosts.find(function(h) { return h.key === hostKey; });
    if (host) { urlEl.textContent = host.url || ''; return; }
  }
}

function selectEnv(envKey) {
  _activeEnv  = envKey;
  const env   = _envs.find(function(e) { return e.key === envKey; });
  _allowRefresh = env ? env.allow_refresh !== false : true;
  _activeHost = env ? env.hosts[0].key : _activeHost;

  _envStats = null;
  const bar = el('envStatsBar');
  if (bar) bar.style.display = 'none';

  buildEnvTabs();
  renderHostPills(envKey);
  updateHostUrl(_activeHost);
  el('credPanel').innerHTML = '';
  loadFromCache();
  loadEnvSummary();
}

function selectHost(hostKey) {
  _activeHost = hostKey;
  renderHostPills(_activeEnv);
  updateHostUrl(hostKey);
  el('credPanel').innerHTML = '';
  loadFromCache();
}

boot();
