/* ldap.js — LDAP settings + org mapping viewer */
'use strict';

var _activeHost = null;
var _activeEnv  = null;
var _envs       = [];
var _data       = null;

function el(id) { return document.getElementById(id); }
function enc(s) { return encodeURIComponent(s); }
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

async function boot() {
  try {
    const res  = await fetch('/api/hosts');
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Unknown error from /api/hosts');
    _envs = data.envs; _activeEnv = data.default_env; _activeHost = data.default_host;
    buildEnvTabs();
    renderHostPills(_activeEnv);
    await loadLdap();
  } catch(e) { showEmpty('&#x2717; ' + esc(e.message)); }
}

function buildEnvTabs() {
  const wrap = el('envTabs');
  wrap.innerHTML = '';
  _envs.forEach(function(env) {
    const b = document.createElement('button');
    b.className = 'env-tab' + (env.key === _activeEnv ? ' active' : '');
    b.id = 'env-tab-' + env.key;
    b.textContent = env.label;
    b.onclick = function() { selectEnv(env.key); };
    wrap.appendChild(b);
  });
}

function selectEnv(envKey) {
  _activeEnv  = envKey;
  _activeHost = _envs.find(function(e){ return e.key === envKey; }).hosts[0].key;
  document.querySelectorAll('.env-tab').forEach(function(t){ t.classList.toggle('active', t.id === 'env-tab-' + envKey); });
  renderHostPills(envKey);
  loadLdap();
}

function renderHostPills(envKey) {
  const wrap = el('hostPills');
  wrap.innerHTML = '';
  _envs.find(function(e){ return e.key === envKey; }).hosts.forEach(function(h){
    const b = document.createElement('button');
    b.className = 'pill' + (h.key === _activeHost ? ' active' : '');
    b.id = 'pill-' + h.key;
    b.textContent = h.label;
    b.onclick = function(){ selectHost(h.key); };
    wrap.appendChild(b);
  });
}

function selectHost(hostKey) {
  _activeHost = hostKey;
  document.querySelectorAll('.pill').forEach(function(p){ p.classList.toggle('active', p.id === 'pill-' + hostKey); });
  loadLdap();
}

async function loadLdap() {
  showEmpty('<span class="spinner"></span> Loading LDAP settings...');
  el('ldapContent').style.display = 'none';
  try {
    const res  = await fetch('/api/ldap?host=' + enc(_activeHost));
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to load LDAP data');
    _data = data;
    renderLdap(data);
  } catch(e) {
    showEmpty('<div class="error-box">&#x2717; ' + esc(e.message) + '</div>No cached data — use Refresh from AAP to fetch.');
  }
}

async function triggerRefresh() {
  const btn = el('refreshBtn');
  btn.disabled = true; btn.textContent = '↺ Refreshing...';
  try {
    const res  = await fetch('/api/ldap?host=' + enc(_activeHost) + '&force=true');
    const data = await res.json();
    if (!data.success) throw new Error(data.error);
    _data = data; renderLdap(data);
  } catch(e) {
    showEmpty('<div class="error-box">&#x2717; ' + esc(e.message) + '</div>');
  } finally {
    btn.disabled = false; btn.textContent = '↺ Refresh from AAP';
  }
}

function showEmpty(msg) {
  el('emptyState').innerHTML = msg;
  el('emptyState').style.display = 'block';
  el('ldapContent').style.display = 'none';
}

function renderLdap(data) {
  if (!data.configured) { showEmpty('No LDAP configuration found on this host.'); return; }
  el('emptyState').style.display  = 'none';
  el('ldapContent').style.display = 'block';

  var mappedCount   = (data.mapped_orgs   || []).length;
  var unmappedCount = (data.unmapped_orgs || []).length;
  var teamCount     = Object.keys(data.team_map || {}).length;

  var html =
    '<div class="stats" style="margin-bottom:24px">' +
    statCard(mappedCount,   'Orgs Mapped',   mappedCount   ? 'var(--success)' : 'var(--muted)') +
    statCard(unmappedCount, 'Orgs Unmapped', unmappedCount ? 'var(--danger)'  : 'var(--success)') +
    statCard(teamCount,     'Team Maps',     'var(--accent)') +
    '</div>';

  // ── Settings categories ───────────────────────────────────────
  var categories = data.categories || {};
  var catNames   = Object.keys(categories);
  if (catNames.length) {
    html += '<div class="ldap-block">';
    html += '<div class="section-meta" style="margin-bottom:16px"><h2>Settings</h2>' +
            '<span class="endpoint-badge">GET /api/v2/settings/ldap/</span></div>';
    catNames.forEach(function(cat) {
      var rows = categories[cat];
      // skip categories where every row is null/not-set
      var hasAny = rows.some(function(r){ return r.value !== null; });
      html += '<div class="cat-label">' + esc(cat) + '</div>';
      html += '<div class="info-grid" style="margin-bottom:14px">';
      rows.forEach(function(row) {
        var val = row.hidden ? '••••••••' : formatValue(row.value);
        html += '<div class="info-row">' +
          '<span class="info-label">' + esc(row.key) + '</span>' +
          '<span class="info-value">' + val + '</span>' +
          '</div>';
      });
      html += '</div>';
    });
    html += '</div>';
  }

  // ── Org map table ─────────────────────────────────────────────
  html += renderOrgMap(data);

  el('ldapContent').innerHTML = html;
  var filterInp = el('orgFilter');
  if (filterInp) filterInp.oninput = function(){ filterOrgTable(this.value); };
}

function renderOrgMap(data) {
  var orgMap       = data.org_map       || {};
  var mappedOrgs   = data.mapped_orgs   || [];
  var unmappedOrgs = data.unmapped_orgs || [];
  var totalOrgs    = mappedOrgs.length + unmappedOrgs.length;
  var rows = '';

  mappedOrgs.forEach(function(orgName) {
    var m = orgMap[orgName] || {};
    rows +=
      '<tr>' +
      '<td><span class="org-name">' + esc(orgName) + '</span></td>' +
      '<td><span class="mapped-badge">&#x2713; Mapped</span></td>' +
      '<td>' + groupTags(extractGroups(m.admins)) + '</td>' +
      '<td>' + groupTags(extractGroups(m.users))  + '</td>' +
      '<td>' + (m.remove_admins ? '<span class="warn-badge">Yes</span>' : '<span class="na">No</span>') + '</td>' +
      '<td>' + (m.remove_users  ? '<span class="warn-badge">Yes</span>' : '<span class="na">No</span>') + '</td>' +
      '</tr>';
  });

  unmappedOrgs.forEach(function(orgName) {
    rows +=
      '<tr class="unmapped-row">' +
      '<td><span class="org-name muted">' + esc(orgName) + '</span></td>' +
      '<td><span class="unmapped-badge">&#x2717; No mapping</span></td>' +
      '<td colspan="4"><span class="na">—</span></td>' +
      '</tr>';
  });

  if (!rows) rows = '<tr><td colspan="6" class="state" style="padding:32px">No organizations in cache — refresh EE first.</td></tr>';

  return '<div class="ldap-block">' +
    '<div class="section-meta">' +
    '<h2>Organization Map</h2>' +
    '<span class="count-badge">' + mappedOrgs.length + ' of ' + totalOrgs + ' orgs mapped</span>' +
    '</div>' +
    '<div class="search-wrap"><input class="search" id="orgFilter" placeholder="Filter organizations..."></div>' +
    '<div class="table-wrap"><table id="orgTable">' +
    '<thead><tr><th>Organization</th><th>Status</th><th>Admin Groups</th><th>User Groups</th><th>Remove Admins</th><th>Remove Members</th></tr></thead>' +
    '<tbody>' + rows + '</tbody>' +
    '</table></div></div>';
}

function formatValue(val) {
  if (val === null || val === undefined || val === '') return '<span class="na">not set</span>';
  if (typeof val === 'boolean') return val ? '<span class="mapped-badge">&#x2713; Yes</span>' : '<span class="na">No</span>';
  if (Array.isArray(val)) {
    if (!val.length) return '<span class="na">empty</span>';
    return val.map(function(item){
      return '<span class="group-tag">' + esc(Array.isArray(item) ? item.join('  ') : String(item)) + '</span>';
    }).join(' ');
  }
  if (typeof val === 'object') return '<span class="json-val">' + esc(JSON.stringify(val)) + '</span>';
  return '<span class="mono-val">' + esc(String(val)) + '</span>';
}

function extractGroups(val) {
  if (!val) return [];
  if (typeof val === 'string') return [val];
  if (Array.isArray(val)) return val.filter(function(v){ return typeof v === 'string'; });
  if (typeof val === 'object') {
    var g = val.ldap_groups || val.has_ldap_group || val.group_dn || '';
    if (typeof g === 'string' && g) return [g];
    if (Array.isArray(g)) return g;
  }
  return [];
}

function groupTags(groups) {
  if (!groups || !groups.length) return '<span class="na">—</span>';
  return groups.map(function(g){
    var match = g.match(/CN=([^,]+)/i);
    var short = match ? match[1] : g;
    return '<span class="group-tag" title="' + esc(g) + '">' + esc(short) + '</span>';
  }).join(' ');
}

function statCard(val, label, color) {
  return '<div class="stat"><div class="stat-val" style="color:' + color + '">' + val + '</div><div class="stat-label">' + label + '</div></div>';
}

function filterOrgTable(q) {
  q = q.toLowerCase();
  document.querySelectorAll('#orgTable tbody tr').forEach(function(row){
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

function exportCSV() {
  if (!_data) return;
  var rows = [['Organization','Status','Admin Groups','User Groups','Remove Admins','Remove Members']];
  var orgMap = _data.org_map || {};
  (_data.mapped_orgs || []).forEach(function(n){
    var m = orgMap[n] || {};
    rows.push([n,'Mapped',
      extractGroups(m.admins).map(function(g){ var x=g.match(/CN=([^,]+)/i); return x?x[1]:g; }).join(' | '),
      extractGroups(m.users).map(function(g){  var x=g.match(/CN=([^,]+)/i); return x?x[1]:g; }).join(' | '),
      m.remove_admins?'Yes':'No', m.remove_users?'Yes':'No']);
  });
  (_data.unmapped_orgs || []).forEach(function(n){ rows.push([n,'No mapping','','','','']); });
  var csv  = rows.map(function(r){ return r.map(function(c){ return '"'+String(c).replace(/"/g,'""')+'"'; }).join(','); }).join('\r\n');
  var blob = new Blob([csv],{type:'text/csv'});
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href=url; a.download='ldap-org-map.csv'; a.click();
  URL.revokeObjectURL(url);
}

window.addEventListener('DOMContentLoaded', boot);
