/* ee.js — Execution Environments (requires common.js) */
'use strict';

var _data      = null;
var _activeRes = 'ees';
var _envStats  = null;

// ── Wiring ────────────────────────────────────────────────────
window._onHostReady = async function() {
  _clearPanels();
  await Promise.all([_load(), _loadEnvSummary()]);
};

window._onEnvChange = function() {
  _envStats = null;
  var bar = el('envStatsBar');
  if (bar) bar.style.display = 'none';
  _activeHost = '__all__';
  buildHostPillsWithAll(_activeEnv);
};

// ── Load — handles single host or all hosts in env ────────────
async function _load() {
  try {
    var hosts = _getTargetHosts();
    var results = await Promise.all(hosts.map(function(hk) {
      return fetch('/api/summary?host=' + enc(hk)).then(function(r){ return r.json(); });
    }));

    // Merge results from all hosts
    var merged = _mergeHostData(results, hosts);
    if (!merged) {
      el('emptyState').innerHTML     = 'No cached data \u2014 press <strong>\u21ba Refresh from AAP</strong>';
      el('emptyState').style.display = 'block';
      renderSyncedBar(null);
      _enableBtn();
      return;
    }

    _data = merged;
    _render(merged);
    renderSyncedBar(merged.synced_at);

  } catch(e) {
    el('emptyState').innerHTML   = '&#x2717; ' + esc(e.message);
    el('emptyState').style.display = 'block';
    renderSyncedBar(null);
    _enableBtn();
  }
}

function _getTargetHosts() {
  if (_activeHost === '__all__') {
    var env = _envs.find(function(e){ return e.key === _activeEnv; });
    return env ? env.hosts.map(function(h){ return h.key; }) : [_activeHost];
  }
  return [_activeHost];
}

function _mergeHostData(results, hostKeys) {
  // Filter to successful results with data
  var valid = results.filter(function(d, i){
    return d.success && (d.ees.length || d.projects.length || d.templates.length);
  });
  if (!valid.length) return null;

  // Deduplicate by id, tag with host label when merging multiple
  var multi = valid.length > 1;

  function dedup(arr, idKey) {
    var seen = {}, out = [];
    arr.forEach(function(item){
      var k = item[idKey];
      if (!seen[k]) { seen[k] = true; out.push(item); }
    });
    return out;
  }

  var ees       = dedup(valid.flatMap(function(d){ return d.ees       || []; }), 'id');
  var orgs      = dedup(valid.flatMap(function(d){ return d.orgs      || []; }), 'id');
  var projects  = dedup(valid.flatMap(function(d){ return d.projects  || []; }), 'id');
  var templates = dedup(valid.flatMap(function(d){ return d.templates || []; }), 'id');

  // Use the most recent synced_at
  var latestSync = valid.reduce(function(latest, d){
    return (!latest || d.synced_at > latest) ? d.synced_at : latest;
  }, null);

  // Rebuild stats from merged data
  var allOrgIds  = new Set(orgs.map(function(o){ return o.id; }));
  var allOrgTotal = valid.reduce(function(max, d){ return Math.max(max, d.stats ? d.stats.total_orgs : 0); }, 0);
  var allProjTotal = valid.reduce(function(sum, d){ return sum + (d.stats ? d.stats.total_projects : 0); }, 0);
  var allTmplTotal = valid.reduce(function(sum, d){ return sum + (d.stats ? d.stats.total_templates : 0); }, 0);

  return {
    success:   true,
    synced_at: latestSync,
    ees:       ees,
    orgs:      orgs,
    projects:  projects,
    templates: templates,
    stats: {
      total_ees:        ees.length,
      total_orgs:       allOrgTotal,
      orgs_with_ee:     orgs.length,
      total_projects:   allProjTotal,
      projects_with_ee: projects.length,
      total_templates:  allTmplTotal,
      templates_with_ee:templates.length,
    }
  };
}

function _clearPanels() {
  _data = null;
  _orgFilter.reset();
  renderSyncedBar(null);
  ['statsRow','resTabs'].forEach(function(id){ var e=el(id); if(e) e.style.display='none'; });
  var exp = el('exportBtn'); if(exp) exp.style.display='none';
  ['ees','orgs','projects','templates'].forEach(function(t){ var p=el('panel-'+t); if(p) p.innerHTML=''; });
  el('emptyState').innerHTML = ''; el('emptyState').style.display = 'block';
  _enableBtn();
}

// ── Render ────────────────────────────────────────────────────
function _render(data) {
  var s = data.stats;

  var sr = el('statsRow');
  sr.innerHTML =
    _sc(s.total_ees, 'Execution Envs') +
    _scBreak(s.total_orgs,       'Organizations', s.orgs_with_ee,       s.total_orgs - s.orgs_with_ee) +
    _scBreak(s.total_projects,   'Projects',      s.projects_with_ee,   s.total_projects - s.projects_with_ee) +
    _scBreak(s.total_templates,  'Job Templates', s.templates_with_ee,  s.total_templates - s.templates_with_ee);
  sr.style.display = 'grid';

  el('panel-ees').innerHTML       = _renderEEs(data.ees);
  el('panel-orgs').innerHTML      = _renderOrgs(data.orgs, s.total_orgs);
  el('panel-projects').innerHTML  = _renderProjects(data.projects, s.total_projects);
  el('panel-templates').innerHTML = _renderTemplates(data.templates, s.total_templates);

  el('emptyState').style.display = 'none';
  el('resTabs').style.display    = 'flex';
  el('exportBtn').style.display  = 'inline-block';
  _enableBtn();
  switchResTab(_activeRes);
}

function _sc(val, label) {
  return '<div class="stat"><div class="stat-val">' + val + '</div><div class="stat-label">' + label + '</div></div>';
}
function _scBreak(total, label, withEE, without) {
  return '<div class="stat"><div class="stat-val">' + total + '</div><div class="stat-label">' + label + '</div>'
    + '<div class="stat-pills"><span class="stat-pill ok">' + withEE + ' with EE</span>'
    + '<span class="stat-pill na">' + without + ' without</span></div></div>';
}

function switchResTab(name) {
  _activeRes = name;
  ['ees','orgs','projects','templates'].forEach(function(t) {
    el('panel-'+t).classList.toggle('active', t===name);
    el('tab-'+t).classList.toggle('active', t===name);
  });
}

// ── Table renderers (each with org filter + search) ───────────
function _renderEEs(ees) {
  var orgs = _uniqueOrgs(ees, 'org');
  var rows = ees.map(function(e) {
    return '<tr data-org="' + esc(e.org||'') + '">'
      + '<td><span class="id-chip">#' + e.id + '</span></td>'
      + '<td><strong>' + esc(e.name) + '</strong></td>'
      + '<td><span class="mono-val image-text">' + esc(e.image) + '</span></td>'
      + '<td><span class="org-badge">' + esc(e.org) + '</span></td>'
      + '</tr>';
  }).join('');
  return _section('Execution Environments', ees.length, null,
    orgs, 'orgbar-ees', 'tbl-ees', 'srch-ees', 'Filter by name or image\u2026',
    '<table id="tbl-ees"><thead><tr><th>ID</th><th>Name</th><th>Image</th><th>Scope</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function _renderOrgs(orgs, total) {
  if (!orgs || !orgs.length) return '<div class="state">No organizations have an EE assigned.</div>';
  var orgNames = _uniqueOrgs(orgs, 'name');
  var rows = orgs.map(function(o) {
    return '<tr data-org="' + esc(o.name||'') + '">'
      + '<td><span class="id-chip">#' + o.id + '</span></td>'
      + '<td><strong>' + esc(o.name) + '</strong></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(o.ee_name) + '</span></td>'
      + '</tr>';
  }).join('');
  return _section('Organizations', orgs.length, total,
    orgNames, 'orgbar-orgs', 'tbl-orgs', 'srch-orgs', 'Filter by org or EE name\u2026',
    '<table id="tbl-orgs"><thead><tr><th>ID</th><th>Organization</th><th>Execution Environment</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function _renderProjects(projects, total) {
  if (!projects.length) return '<div class="state">No projects have an EE assigned.</div>';
  var orgs = _uniqueOrgs(projects, 'org_name');
  var rows = projects.map(function(p) {
    return '<tr data-org="' + esc(p.org_name||'') + '">'
      + '<td><span class="id-chip">#' + p.id + '</span></td>'
      + '<td><strong>' + esc(p.name) + '</strong></td>'
      + '<td><span class="org-badge">' + esc(p.org_name||'\u2014') + '</span></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(p.ee_name) + '</span></td>'
      + '</tr>';
  }).join('');
  return _section('Projects', projects.length, total,
    orgs, 'orgbar-projects', 'tbl-projects', 'srch-projects', 'Filter by project, org or EE\u2026',
    '<table id="tbl-projects"><thead><tr><th>ID</th><th>Project</th><th>Organization</th><th>Execution Environment</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

function _renderTemplates(templates, total) {
  if (!templates.length) return '<div class="state">No job templates have an EE assigned.</div>';
  var orgs = _uniqueOrgs(templates, 'org_name');
  var rows = templates.map(function(t) {
    return '<tr data-org="' + esc(t.org_name||'') + '">'
      + '<td><span class="id-chip">#' + t.id + '</span></td>'
      + '<td><strong>' + esc(t.name) + '</strong></td>'
      + '<td><span class="org-badge">' + esc(t.org_name||'\u2014') + '</span></td>'
      + '<td><span class="ee-tag"><span class="dot"></span>' + esc(t.ee_name) + '</span></td>'
      + '</tr>';
  }).join('');
  return _section('Job Templates', templates.length, total,
    orgs, 'orgbar-templates', 'tbl-templates', 'srch-templates', 'Filter by template, org or EE\u2026',
    '<table id="tbl-templates"><thead><tr><th>ID</th><th>Template</th><th>Organization</th><th>Execution Environment</th></tr></thead><tbody>' + rows + '</tbody></table>');
}

// Each section has its own independent org filter + search
function _section(title, count, total, orgs, barId, tableId, searchId, placeholder, tableHtml) {
  var badge = total != null ? (count + ' of ' + total + ' have EE') : (count + ' total');
  var orgBar = orgs.length > 1
    ? '<div class="org-filter-bar" id="' + barId + '">'
      + '<button class="org-pill active" onclick="_tabFilter(\'' + barId + '\',\'' + tableId + '\',\'' + searchId + '\', null)">All</button>'
      + orgs.map(function(o){
          return '<button class="org-pill" onclick="_tabFilter(\'' + barId + '\',\'' + tableId + '\',\'' + searchId + '\',\'' + esc(o) + '\')">' + esc(o) + '</button>';
        }).join('')
      + '</div>'
    : '';
  return '<div class="section-meta"><h2>' + title + '</h2><span class="count-badge">' + badge + '</span></div>'
    + orgBar
    + '<div class="search-wrap"><input class="search" id="' + searchId + '" placeholder="' + placeholder + '" oninput="_tabSearch(\'' + tableId + '\',\'' + searchId + '\',\'' + barId + '\')"/></div>'
    + '<div class="table-wrap">' + tableHtml + '</div>';
}

// Per-tab filter state
var _tabActiveOrg = {};

function _tabFilter(barId, tableId, searchId, org) {
  _tabActiveOrg[tableId] = org;
  document.querySelectorAll('#' + barId + ' .org-pill').forEach(function(b){
    b.classList.toggle('active', org === null ? b.textContent === 'All' : b.textContent === org);
  });
  _applyTabFilters(tableId, searchId);
}

function _tabSearch(tableId, searchId, barId) {
  _applyTabFilters(tableId, searchId);
}

function _applyTabFilters(tableId, searchId) {
  var org = _tabActiveOrg[tableId] !== undefined ? _tabActiveOrg[tableId] : null;
  var q   = el(searchId) ? el(searchId).value.toLowerCase() : '';
  document.querySelectorAll('#' + tableId + ' tbody tr').forEach(function(row){
    var orgOk  = org === null || row.dataset.org === org;
    var textOk = !q || row.textContent.toLowerCase().includes(q);
    row.style.display = (orgOk && textOk) ? '' : 'none';
  });
}

function _uniqueOrgs(items, key) {
  var seen = {}, orgs = [];
  items.forEach(function(item){
    var v = item[key] || '';
    if (v && !seen[v]) { seen[v] = true; orgs.push(v); }
  });
  return orgs.sort();
}

// ── Env summary bar ───────────────────────────────────────────
async function _loadEnvSummary() {
  await loadEnvSummary(function(data) {
    _envStats = data;
    var bar = el('envStatsBar');
    if (!bar) return;
    var t = data.totals || {}, hosts = data.hosts || [];
    var online = hosts.filter(function(h){ return h.has_data; }).length;
    bar.innerHTML =
      '<span class="env-stats-label">' + esc(data.env_label) + ' totals</span>' +
      envStatChip(t.total_ees         || 0, 'EEs') +
      envStatChip(t.orgs_with_ee      || 0, 'Orgs w/ EE',      t.total_orgs) +
      envStatChip(t.projects_with_ee  || 0, 'Projects w/ EE',  t.total_projects) +
      envStatChip(t.templates_with_ee || 0, 'Templates w/ EE', t.total_templates) +
      '<span class="env-stats-hosts">' + online + ' / ' + hosts.length + ' hosts cached</span>';
    bar.style.display = 'flex';
  });
}

function triggerRefresh() {
  if (_activeHost === '__all__') {
    var env = _envs.find(function(e){ return e.key === _activeEnv; });
    if (!env) return;
    // Refresh all hosts in parallel
    Promise.all(env.hosts.map(function(h){ return startRefresh('ee', h.key); }));
  } else {
    startRefresh('ee');
  }
}

// ── CSV ───────────────────────────────────────────────────────
function exportCSV() {
  if (!_data) return;
  var lines = ['Section,ID,Name,Image/EE,Org'];
  _data.ees.forEach(function(e)      { lines.push('EE,'      +e.id+',"'+e.name+'","'+e.image+'","'+e.org+'"'); });
  _data.projects.forEach(function(p) { lines.push('Project,' +p.id+',"'+p.name+'","'+p.ee_name+'","'+(p.org_name||'')+'"'); });
  _data.templates.forEach(function(t){ lines.push('Template,'+t.id+',"'+t.name+'","'+t.ee_name+'","'+(t.org_name||'')+'"'); });
  var a = document.createElement('a');
  a.href     = URL.createObjectURL(new Blob([lines.join('\n')],{type:'text/csv'}));
  a.download = 'ee-' + _activeEnv + '.csv';
  a.click();
}

// After commonBoot resolves env/host, replace pills with All-aware version
window._postBoot = function() {
  _activeHost = '__all__';
  buildHostPillsWithAll(_activeEnv);
};

window.addEventListener('DOMContentLoaded', commonBoot);
